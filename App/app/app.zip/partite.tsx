// app/partite.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import CompetitionModal from './components/partite/CompetitionModal';
import ConfirmDeleteModal from './components/partite/ConfirmDeleteModal';
import MatchEventCard from './components/partite/MatchEventCard';
import SingleMatchModal from './components/partite/SingleMatchModal';
import { CalendarEvent, STORAGE_KEY } from './data/events';

// Estensione locale con campi opzionali (retrocompatibile)
type MatchEvent = CalendarEvent & {
  competition?: string;
  homeAway?: 'CASA' | 'TRASFERTA';
};

type NewRound = {
  opponent: string;
  date: string;
  time: string;
  homeAway: 'CASA' | 'TRASFERTA';
  location: string;
};

const TIME_RE = /^\d{2}:\d{2}$/;

export default function Partite() {
  const router = useRouter();
  const [events, setEvents] = useState<MatchEvent[]>([]);

  // modali creazione
  const [showSingleModal, setShowSingleModal] = useState(false);
  const [showCompModal, setShowCompModal] = useState(false);

  // scelte/eliminazioni
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  // flusso "elimina competizione"
  const [showChooseCompModal, setShowChooseCompModal] = useState(false); // nuova modale di scelta
  const [confirmDeleteComp, setConfirmDeleteComp] = useState(false);     // conferma finale (già esistente)
  const [compToDelete, setCompToDelete] = useState<string>('—');         // competizione selezionata

  const [busy, setBusy] = useState(false);

  const loadEvents = async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const list: MatchEvent[] = raw ? JSON.parse(raw) : [];
    setEvents(list.filter((e) => e.type === 'PARTITA'));
  };

  useFocusEffect(useCallback(() => { loadEvents(); }, []));

  const openPartita = (ev: MatchEvent) => {
    router.push({ pathname: '/eventi/partita/[id]/live', params: { id: ev.id } });
  };

  // Competizioni esistenti + contatori
  const competitions = useMemo(() => {
    const map = new Map<string, number>();
    events.forEach((e) => {
      const key = e.competition || '—';
      map.set(key, (map.get(key) || 0) + 1);
    });
    return Array.from(map.entries()).map(([name, count]) => ({ name, count }));
  }, [events]);

  // --- Elimina singola ---
  const actuallyDeleteOne = async () => {
    if (!confirmDeleteId) return;
    setBusy(true);
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    const updated = all.filter((ev) => ev.id !== confirmDeleteId);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setBusy(false);
    setConfirmDeleteId(null);
    loadEvents();
  };

  // --- Elimina tutte le PARTITE ---
  const actuallyDeleteAllMatches = async () => {
    setBusy(true);
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    const keep = all.filter((ev) => ev.type !== 'PARTITA'); // mantieni solo NON-partite
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(keep));
    setBusy(false);
    setConfirmDeleteAll(false);
    loadEvents();
  };

  // --- Elimina intera competizione ---
  const actuallyDeleteCompetition = async () => {
    setBusy(true);
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: MatchEvent[] = raw ? JSON.parse(raw) : [];
    const keep = all.filter(
      (ev) => ev.type !== 'PARTITA' || (ev.type === 'PARTITA' && (ev.competition || '—') !== compToDelete)
    );
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(keep));
    setBusy(false);
    setConfirmDeleteComp(false);
    loadEvents();
  };

  // Handlers creazione
  const handleCreateSingleMatch = async (matchData: {
    date: string;
    time: string;
    opponent: string;
    competition: string;
    homeAway: 'CASA' | 'TRASFERTA';
    location: string;
  }) => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: MatchEvent[] = raw ? JSON.parse(raw) : [];

    // Duplica? (semplice controllo)
    const exists = all.some(
      (ev) =>
        ev.type === 'PARTITA' &&
        ev.date === matchData.date &&
        ev.time === matchData.time &&
        ev.opponent === matchData.opponent &&
        (matchData.competition ? (ev.competition || '') === matchData.competition : true)
    );
    if (exists) {
      setShowSingleModal(false);
      return;
    }

    const newMatch: MatchEvent = {
      id: `${Date.now()}-${matchData.date}-${matchData.time}-${Math.random().toString(36).slice(2, 6)}`,
      type: 'PARTITA',
      date: matchData.date,
      time: matchData.time,
      location: matchData.location,
      opponent: matchData.opponent,
      competition: matchData.competition || undefined,
      homeAway: matchData.homeAway,
      formationSlots: undefined,
      benchIds: [],
      tacticsIds: [],
    };

    const updated = [...all, newMatch];
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setShowSingleModal(false);
    loadEvents();
  };

  const handleCreateCompetition = async (competitionData: {
    name: string;
    rounds: NewRound[];
  }) => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: MatchEvent[] = raw ? JSON.parse(raw) : [];

    const validRound = (r: NewRound) => !!r.opponent && !!r.location && !!r.date && TIME_RE.test(r.time);

    const toAdd: MatchEvent[] = [];
    competitionData.rounds.forEach((r) => {
      if (!validRound(r)) return;

      // duplica?
      const exists = all.some(
        (ev) =>
          ev.type === 'PARTITA' &&
          ev.date === r.date &&
          ev.time === r.time &&
          (ev.competition || '') === competitionData.name
      );
      if (exists) return;

      toAdd.push({
        id: `${Date.now()}-${r.date}-${r.time}-${Math.random().toString(36).slice(2, 6)}`,
        type: 'PARTITA',
        date: r.date,
        time: r.time,
        location: r.location,
        opponent: r.opponent,
        competition: competitionData.name,
        homeAway: r.homeAway,
        formationSlots: undefined,
        benchIds: [],
        tacticsIds: [],
      } as MatchEvent);
    });

    if (toAdd.length === 0) {
      setShowCompModal(false);
      return;
    }

    const updated = [...all, ...toAdd];
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setShowCompModal(false);
    loadEvents();
  };

  const renderItem = ({ item }: { item: MatchEvent }) => (
    <MatchEventCard item={item} onPress={openPartita} onDelete={(id) => setConfirmDeleteId(id)} />
  );

  // stato locale per la selezione nella modale
  const [selectedComp, setSelectedComp] = useState<string>('—');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tutte le Partite</Text>

      {/* Azioni sopra la lista */}
      <View style={styles.topActions}>
        <Pressable
          style={[styles.outlineBtn, { borderColor: '#b91c1c' }]}
          onPress={() => setConfirmDeleteAll(true)}
        >
          <Text style={[styles.outlineText, { color: '#b91c1c' }]}>🧹 Rimuovi tutte</Text>
        </Pressable>

        <Pressable
          style={[styles.outlineBtn, { borderColor: '#1f2937' }]}
          onPress={() => {
            const first = competitions[0]?.name ?? '—';
            setSelectedComp(first);
            setShowChooseCompModal(true);
          }}
        >
          <Text style={[styles.outlineText, { color: '#1f2937' }]}>🏷️ Rimuovi competizione</Text>
        </Pressable>
      </View>

      <FlatList
        data={[...events].sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text>Nessuna partita trovata</Text>}
        renderItem={renderItem}
      />

      {/* CTA bottom */}
      <View style={styles.bottomActions}>
        <Pressable style={[styles.cta, { backgroundColor: '#1b7f3b' }]} onPress={() => setShowSingleModal(true)}>
          <Text style={styles.ctaText}>CREA PARTITA</Text>
        </Pressable>
        <Pressable style={[styles.cta, { backgroundColor: '#1b4f7f' }]} onPress={() => setShowCompModal(true)}>
          <Text style={styles.ctaText}>CREA CALENDARIO COMPETIZIONE</Text>
        </Pressable>
      </View>

      {/* Modali creazione */}
      <SingleMatchModal
        visible={showSingleModal}
        onClose={() => setShowSingleModal(false)}
        onCreateMatch={handleCreateSingleMatch}
      />
      <CompetitionModal
        visible={showCompModal}
        onClose={() => setShowCompModal(false)}
        onCreateCompetition={handleCreateCompetition}
      />

      {/* Modale: SCEGLI COMPETIZIONE DA CANCELLARE */}
      <Modal visible={showChooseCompModal} transparent animationType="fade" onRequestClose={() => setShowChooseCompModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Seleziona competizione</Text>

            {competitions.length === 0 ? (
              <Text style={{ marginBottom: 12 }}>Nessuna competizione trovata</Text>
            ) : (
              <>
                <View style={styles.pickerWrap}>
                  <Picker
                    selectedValue={selectedComp}
                    onValueChange={(val) => setSelectedComp(val)}
                    style={{ width: '100%' }}
                  >
                    {competitions.map((c) => (
                      <Picker.Item key={c.name} label={`${c.name} (${c.count})`} value={c.name} />
                    ))}
                  </Picker>
                </View>

                <View style={{ height: 10 }} />

                <Pressable
                  style={[styles.cta, { backgroundColor: '#b91c1c' }]}
                  onPress={() => {
                    setCompToDelete(selectedComp);
                    setShowChooseCompModal(false);
                    setConfirmDeleteComp(true); // apre la conferma finale che già avevi
                  }}
                >
                  <Text style={styles.ctaText}>Prosegui</Text>
                </Pressable>
              </>
            )}

            <View style={{ height: 8 }} />

            <Pressable style={[styles.cta, { backgroundColor: '#9ca3af' }]} onPress={() => setShowChooseCompModal(false)}>
              <Text style={styles.ctaText}>Annulla</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {/* Conferme eliminazione */}
      <ConfirmDeleteModal
        visible={!!confirmDeleteId}
        title="Eliminare questa partita?"
        message="L'operazione non può essere annullata."
        onConfirm={actuallyDeleteOne}
        onCancel={() => setConfirmDeleteId(null)}
        busy={busy}
      />

      <ConfirmDeleteModal
        visible={confirmDeleteAll}
        title="Eliminare TUTTE le partite?"
        message="Questa operazione eliminerà definitivamente tutte le partite."
        onConfirm={actuallyDeleteAllMatches}
        onCancel={() => setConfirmDeleteAll(false)}
        busy={busy}
      />

      <ConfirmDeleteModal
        visible={confirmDeleteComp}
        title="Elimina competizione"
        message={
          competitions.length === 0
            ? 'Nessuna competizione trovata'
            : `Eliminare la competizione "${compToDelete}"?`
        }
        onConfirm={actuallyDeleteCompetition}
        onCancel={() => setConfirmDeleteComp(false)}
        busy={busy}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },

  topActions: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  outlineBtn: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1 },
  outlineText: { fontWeight: '800' },

  bottomActions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  cta: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  ctaText: { color: 'white', fontWeight: '800' },

  // Modal choose competition
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center', alignItems: 'center',
  },
  modalBox: {
    backgroundColor: '#fff', borderRadius: 10, padding: 16,
    width: '92%', maxWidth: 520,
  },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 12 },
  pickerWrap: {
    borderWidth: 1, borderColor: '#ddd', borderRadius: 8,
    overflow: 'hidden', backgroundColor: '#fafafa',
  },
});
