// app/calendario.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import EventEditorModal from './components/EventEditorModal';
import { CalendarEvent, STORAGE_KEY } from './data/events';

export default function Calendario() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [showModal, setShowModal] = useState(false);
  const router = useRouter();

  const loadEvents = async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const list: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    setEvents(list);
  };

  useFocusEffect(useCallback(() => { loadEvents(); }, []));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calendario</Text>

      <FlatList
        data={[...events].sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text>Nessun evento trovato</Text>}
        renderItem={({ item }) => (
          <Pressable
            style={styles.eventCard}
            onPress={() =>
              item.type === 'PARTITA'
                ? router.push(`/eventi/partita/${item.id}/live`)
                : router.push(`/eventi/allenamento/${item.id}`)
            }
          >
            <Text style={styles.eventTitle}>
              {item.type === 'PARTITA' ? `Partita vs ${item.opponent}` : 'Allenamento'}
            </Text>
            <Text>{item.date} · {item.time} · {item.location}</Text>
          </Pressable>
        )}
      />

      {/* Un solo bottone "Nuovo" che apre la modale comune */}
      <Pressable style={[styles.addBtn, { backgroundColor: '#1b7f3b' }]} onPress={() => setShowModal(true)}>
        <Text style={styles.addBtnText}>+ Nuovo</Text>
      </Pressable>

      <EventEditorModal
        visible={showModal}
        onClose={() => setShowModal(false)}
        onSaved={loadEvents}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  eventCard: { backgroundColor: '#eee', borderRadius: 8, padding: 10, marginBottom: 8 },
  eventTitle: { fontWeight: '700', marginBottom: 2 },
  addBtn: { marginTop: 12, padding: 12, borderRadius: 8, alignItems: 'center' },
  addBtnText: { color: '#fff', fontWeight: '700' },
});
