// app/components/EventEditorModal.tsx
import React, { useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import EventEditor from './EventEditor';

type EventType = 'PARTITA' | 'ALLENAMENTO';

interface Props {
  visible: boolean;
  initialType?: EventType;
  onClose: () => void;
  onSaved: () => void;
  initialDate?: string; // nuova prop
}

export default function EventEditorModal({
  visible,
  initialType = 'PARTITA',
  onClose,
  onSaved,
  initialDate,
}: Props) {
  const [type, setType] = useState<EventType>(initialType);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.content}>
          {/* Toggle tipo evento */}
          <View style={styles.typeRow}>
            <Pressable
              style={[styles.typeBtn, type === 'PARTITA' && styles.typeBtnActive]}
              onPress={() => setType('PARTITA')}
            >
              <Text style={[styles.typeText, type === 'PARTITA' && styles.typeTextActive]}>
                Partita
              </Text>
            </Pressable>
            <Pressable
              style={[styles.typeBtn, type === 'ALLENAMENTO' && styles.typeBtnActive]}
              onPress={() => setType('ALLENAMENTO')}
            >
              <Text style={[styles.typeText, type === 'ALLENAMENTO' && styles.typeTextActive]}>
                Allenamento
              </Text>
            </Pressable>
          </View>

          {/* Editor riutilizzabile */}
          <EventEditor
            initialType={type}
            initialDate={initialDate}   // <-- passata qui
            onCancel={onClose}
            onSaved={() => {
              onSaved();
              onClose();
            }}
          />

          <Pressable style={styles.closeBtn} onPress={onClose}>
            <Text style={styles.closeText}>Chiudi</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  content: { backgroundColor: 'white', padding: 16, borderRadius: 10, width: '92%', maxHeight: '92%' },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  typeBtn: { flex: 1, paddingVertical: 10, borderRadius: 8, backgroundColor: '#eee', alignItems: 'center' },
  typeBtnActive: { backgroundColor: '#1b7f3b' },
  typeText: { fontWeight: '700', color: '#333' },
  typeTextActive: { color: 'white' },
  closeBtn: { marginTop: 10, padding: 10, backgroundColor: '#ccc', borderRadius: 6, alignItems: 'center' },
  closeText: { fontWeight: '700' },
});
