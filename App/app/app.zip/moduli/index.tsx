import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { MODULES as DEFAULT_MODULES, FieldSlot } from '../utils/modules-layout';

type CustomModule = { name: string; slots: FieldSlot[] };
const CUSTOM_KEY = 'modules/custom';

export default function ModuliIndex() {
  const router = useRouter();

  const defaultNames = useMemo(() => Object.keys(DEFAULT_MODULES), []);
  const [custom, setCustom] = useState<CustomModule[]>([]);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const raw = await AsyncStorage.getItem(CUSTOM_KEY);
    const list: CustomModule[] = raw ? JSON.parse(raw) : [];
    setCustom(list);
  };

  useFocusEffect(
    useCallback(() => {
      load();
    }, [])
  );

  const createNew = () => {
    router.push('/moduli/editor'); // nuovo modulo
  };

  const openDefault = (name: string) => {
    router.push({ pathname: '/moduli/editor', params: { name, readonly: '1' } });
  };

  const openCustom = (name: string) => {
    router.push({ pathname: '/moduli/editor', params: { name } });
  };

  // === pattern uguale alle partite ===
  const actuallyDeleteOne = async () => {
    if (!confirmDeleteId) return;
    setBusy(true);
    const raw = await AsyncStorage.getItem(CUSTOM_KEY);
    const all: CustomModule[] = raw ? JSON.parse(raw) : [];
    const updated = all.filter((m) => m.name !== confirmDeleteId);
    await AsyncStorage.setItem(CUSTOM_KEY, JSON.stringify(updated));
    setBusy(false);
    setConfirmDeleteId(null);
    load();
  };

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Text style={styles.title}>Moduli</Text>
        <Pressable style={styles.createBtn} onPress={createNew}>
          <Text style={styles.createBtnText}>＋ Crea nuovo modulo</Text>
        </Pressable>
      </View>

      <Text style={styles.section}>Predefiniti</Text>
      <FlatList
        data={defaultNames}
        keyExtractor={(n) => `def-${n}`}
        renderItem={({ item }) => (
          <Pressable style={styles.row} onPress={() => openDefault(item)}>
            <Text style={styles.rowText}>{item}</Text>
            <Text style={styles.badge}>Default</Text>
          </Pressable>
        )}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
      />

      <Text style={[styles.section, { marginTop: 16 }]}>I miei moduli</Text>
      <FlatList
        data={custom}
        keyExtractor={(m) => `cus-${m.name}`}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Pressable style={{ flex: 1 }} onPress={() => openCustom(item.name)}>
              <Text style={styles.rowText}>{item.name}</Text>
            </Pressable>
            <Pressable style={styles.deleteBtn} onPress={() => setConfirmDeleteId(item.name)}>
              <Text style={styles.deleteText}>🗑️</Text>
            </Pressable>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        ListEmptyComponent={<Text style={{ color: '#6b7280' }}>Nessun modulo personalizzato</Text>}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      {/* Modale conferma cancellazione singola (solo custom) */}
      <Modal visible={!!confirmDeleteId} transparent animationType="fade" onRequestClose={() => setConfirmDeleteId(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Eliminare il modulo "{confirmDeleteId}"?</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <Pressable style={[styles.btn, { backgroundColor: '#9ca3af', flex: 1 }]} onPress={() => setConfirmDeleteId(null)}>
                <Text style={styles.btnText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.btn, { backgroundColor: '#b91c1c', flex: 1, opacity: busy ? 0.6 : 1 }]}
                disabled={busy}
                onPress={actuallyDeleteOne}
              >
                <Text style={styles.btnText}>Elimina</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: '#fff' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  title: { fontSize: 22, fontWeight: '800' },
  createBtn: { backgroundColor: '#1b7f3b', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8 },
  createBtnText: { color: 'white', fontWeight: '800' },

  section: { fontSize: 16, fontWeight: '800', marginTop: 8, marginBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f4f6f8', borderRadius: 10, padding: 10, gap: 10 },
  rowText: { fontWeight: '800', fontSize: 16, flex: 1 },
  badge: { backgroundColor: '#e5e7eb', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, color: '#111' },

  deleteBtn: { paddingHorizontal: 8, paddingVertical: 6 },
  deleteText: { fontSize: 16 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '90%', maxWidth: 420, backgroundColor: '#fff', borderRadius: 12, padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  btn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  btnText: { color: 'white', fontWeight: '800', textAlign: 'center' },
});
