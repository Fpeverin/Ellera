// app/moduli/editor.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams, useRouter, type Href } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Dimensions, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { MODULES as DEFAULT_MODULES, FieldSlot } from '../utils/modules-layout';

type CustomModule = {
  name: string;
  slots: FieldSlot[]; // sempre 11
};

const CUSTOM_KEY = 'modules/custom';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const FIELD_W = Math.round(SCREEN_W * 0.7);
const FIELD_H = Math.max(Math.round(SCREEN_H * 0.8), 520);

// dimensioni maglia sul campo
const SHIRT_W = 54;
const SHIRT_H = 36;

/* ----------------------- Bottone "maglia" (colonna destra) ---------------------- */
function ShirtButton({
  label,
  active,
  disabled,
  onPress,
}: {
  label: string;
  active?: boolean;
  disabled?: boolean;
  onPress?: () => void;
}) {
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={[
        styles.shirtWrap,
        active && styles.shirtActive,
        disabled && { opacity: 0.5 },
      ]}
    >
      {/* corpo a righe verticali bianco/azzurre */}
      <View style={styles.shirtBody}>
        {[0, 1, 2, 3, 4].map((i) => (
          <View
            key={i}
            style={{
              flex: 1,
              backgroundColor: i % 2 === 0 ? '#ffffff' : '#3b82f6',
            }}
          />
        ))}
        {/* maniche azzurre */}
        <View style={[styles.sleeve, { left: -8 }]} />
        <View style={[styles.sleeve, { right: -8 }]} />
      </View>
      <Text style={styles.shirtNum}>{label}</Text>
      <Text style={styles.shirtHint}>Tocca, poi tocca il campo</Text>
    </Pressable>
  );
}

/* ------------------------------ Maglia draggable (campo) ------------------------------ */
function DraggableShirt({
  index,
  editable,
  xPct,
  yPct,
  onMove,
}: {
  index: number;
  editable: boolean;
  xPct: number;
  yPct: number;
  onMove: (i: number, xPct: number, yPct: number) => void;
}) {
  const x = useSharedValue((xPct / 100) * FIELD_W - SHIRT_W / 2);
  const y = useSharedValue((yPct / 100) * FIELD_H - SHIRT_H / 2);

  const pan = Gesture.Pan()
    .onChange((e) => {
      if (!editable) return;
      x.value += e.changeX;
      y.value += e.changeY;
    })
    .onEnd(() => {
      if (!editable) return;
      const nx = Math.max(0, Math.min(100, ((x.value + SHIRT_W / 2) / FIELD_W) * 100));
      const ny = Math.max(0, Math.min(100, ((y.value + SHIRT_H / 2) / FIELD_H) * 100));
      onMove(index, nx, ny);
    });

  const style = useAnimatedStyle(() => ({
    position: 'absolute',
    left: withSpring(x.value, { damping: 18, stiffness: 220 }),
    top: withSpring(y.value, { damping: 18, stiffness: 220 }),
    width: SHIRT_W,
    height: SHIRT_H,
    alignItems: 'center',
    justifyContent: 'center',
  }));

  return (
    <GestureDetector gesture={editable ? pan : Gesture.Tap()}>
      <Animated.View style={style}>
        {/* maglia a righe verticali bianco/azzurre */}
        <View style={styles.fieldShirtBody}>
          {[0, 1, 2, 3, 4].map((i) => (
            <View
              key={i}
              style={{
                flex: 1,
                backgroundColor: i % 2 === 0 ? '#ffffff' : '#3b82f6',
              }}
            />
          ))}
          {/* maniche azzurre */}
          <View style={[styles.fieldSleeve, { left: -10 }]} />
          <View style={[styles.fieldSleeve, { right: -10 }]} />
        </View>
        <Text style={styles.fieldShirtNum}>{index + 1}</Text>
      </Animated.View>
    </GestureDetector>
  );
}

export default function ModuleEditor() {
  const router = useRouter();
  const { name, readonly } = useLocalSearchParams<{ name?: string; readonly?: string }>();

  const isEditingExisting = !!name;
  const isReadOnly = readonly === '1';

  // slots: sempre 11 elementi; per i "non piazzati" le coord sono irrilevanti
  const [slots, setSlots] = useState<FieldSlot[]>([]);
  // available[i] === true => maglia i (0..10) ancora da posare; false => già in campo
  const [available, setAvailable] = useState<boolean[]>(Array(11).fill(true));
  const [placingIndex, setPlacingIndex] = useState<number | null>(null);

  const [title, setTitle] = useState(name || '');
  const [showNameModal, setShowNameModal] = useState(false);

  const fieldRef = useRef<View>(null);

  /* -------------------- init: carica default/custom o nuovo -------------------- */
  useEffect(() => {
    (async () => {
      // apri modulo di default (readonly)
      if (isEditingExisting && DEFAULT_MODULES[name!]) {
        const def = DEFAULT_MODULES[name!];
        setSlots(def);
        setAvailable(Array(11).fill(false)); // tutte già in campo
        return;
      }

      // apri modulo personalizzato esistente
      const raw = await AsyncStorage.getItem(CUSTOM_KEY);
      const custom: CustomModule[] = raw ? JSON.parse(raw) : [];
      const found = isEditingExisting ? custom.find((m) => m.name === name) : undefined;
      if (found) {
        setSlots(found.slots);
        setAvailable(Array(11).fill(false)); // tutte già in campo
        return;
      }

      // nuovo: 11 “vuoti”, tutti disponibili a destra, campo vuoto
      const base: FieldSlot[] = Array.from({ length: 11 }, (_, i) => ({
        id: `P${i + 1}`,
        x: 50, // coord placeholder; non visibili finché available[i] è true
        y: 50,
      }));
      setSlots(base);
      setAvailable(Array(11).fill(true));
    })();
  }, [name, isEditingExisting]);

  const jerseyIndices = useMemo(() => Array.from({ length: 11 }, (_, i) => i), []);
  const allPlaced = useMemo(() => available.every((v) => !v), [available]);

  /* --------------------- Tap campo: piazza maglia selezionata --------------------- */
  const handlePlaceOnField = (evt: any) => {
    if (placingIndex === null || isReadOnly) return;
    if (!available[placingIndex]) { setPlacingIndex(null); return; }

    const { locationX, locationY } = evt.nativeEvent;
    const nx = Math.max(0, Math.min(100, (locationX / FIELD_W) * 100));
    const ny = Math.max(0, Math.min(100, (locationY / FIELD_H) * 100));

    setSlots((prev) => {
      const next = [...prev];
      const id = next[placingIndex].id;
      next[placingIndex] = { id, x: nx, y: ny };
      return next;
    });

    setAvailable((prev) => {
      const n = [...prev];
      n[placingIndex] = false;
      return n;
    });

    setPlacingIndex(null);
  };

  /* ---------------------------- Drag maglia in campo ---------------------------- */
  const handleMove = (idx: number, nx: number, ny: number) => {
    if (isReadOnly) return;
    setSlots((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], x: nx, y: ny };
      return next;
    });
  };

  /* --------------------------- core: salva su storage --------------------------- */
  const saveCustomCore = async (finalName: string) => {
    const raw = await AsyncStorage.getItem(CUSTOM_KEY);
    const list: CustomModule[] = raw ? JSON.parse(raw) : [];

    const existsIdx = list.findIndex((m) => m.name === finalName);
    const payload: CustomModule = { name: finalName, slots };

    if (existsIdx >= 0) list[existsIdx] = payload;
    else list.push(payload);

    await AsyncStorage.setItem(CUSTOM_KEY, JSON.stringify(list));
  };

  /* ---------------------- conferma + salva + vai alla lista --------------------- */
  const requestConfirmAndSave = (label: 'salvare' | 'aggiornare') => {
    if (!allPlaced) {
      Alert.alert('Mancano maglie', 'Devi posizionare tutte le 11 maglie prima di ' + label + '.');
      return;
    }
    const key = title.trim();
    if (!key) { setShowNameModal(true); return; }

    Alert.alert(
      'Conferma',
      `Vuoi ${label} il modulo "${key}"?`,
      [
        { text: 'Annulla', style: 'cancel' },
        {
          text: 'Conferma',
          style: 'destructive',
          onPress: async () => {
            await saveCustomCore(key);
            // Torna alla lista moduli (cast a Href per evitare l'errore TS sulle route)
            router.replace('/moduli' as Href);
          },
        },
      ],
      { cancelable: true }
    );
  };

  /* ----------------------------- reset con conferma ---------------------------- */
  const confirmReset = () => {
    Alert.alert(
      'Ripulire il campo?',
      'Questa azione rimuove tutte le maglie dal campo.',
      [
        { text: 'Annulla', style: 'cancel' },
        {
          text: 'Conferma',
          style: 'destructive',
          onPress: () => {
            setAvailable(Array(11).fill(true));
            setSlots((prev) => prev.map((s) => ({ ...s, x: 50, y: 50 })));
            setPlacingIndex(null);
          },
        },
      ]
    );
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        {/* SINISTRA: Campo */}
        <View style={styles.leftCol}>
          <Text style={styles.title}>
            {isEditingExisting ? title : 'Nuovo Modulo'}
            {isReadOnly ? ' (solo lettura)' : ''}
          </Text>

          <View
            ref={fieldRef}
            style={styles.field}
            onStartShouldSetResponder={() => true}
            onResponderRelease={handlePlaceOnField}
          >
            {/* Linee campo */}
            <View style={styles.midLine} />
            <View style={styles.centerCircle} />

            {/* Aree di rigore & porte */}
            <View style={[styles.penaltyBox, styles.topPenaltyBox]} />
            <View style={[styles.sixYardBox, styles.topSixYard]} />
            <View style={[styles.goal, styles.topGoal]} />

            <View style={[styles.penaltyBox, styles.bottomPenaltyBox]} />
            <View style={[styles.sixYardBox, styles.bottomSixYard]} />
            <View style={[styles.goal, styles.bottomGoal]} />

            {/* Magliette piazzate */}
            {slots.map((s, i) =>
              available[i] ? null : (
                <DraggableShirt
                  key={s.id}
                  index={i}
                  editable={!isReadOnly}
                  xPct={s.x}
                  yPct={s.y}
                  onMove={handleMove}
                />
              )
            )}
          </View>

          {!isReadOnly && (
            <>
              <Text style={styles.counterText}>
                Maglie piazzate: {11 - available.filter(Boolean).length}/11
              </Text>

              <View style={styles.bottomBar}>
                <Pressable style={[styles.btn, { backgroundColor: '#d46f00' }]} onPress={confirmReset}>
                  <Text style={styles.btnText}>Reset posizioni</Text>
                </Pressable>

                <Pressable
                  style={[styles.btn, { backgroundColor: allPlaced ? '#1b7f3b' : '#9ca3af' }]}
                  disabled={!allPlaced}
                  onPress={() => requestConfirmAndSave(isEditingExisting ? 'aggiornare' : 'salvare')}
                >
                  <Text style={styles.btnText}>{isEditingExisting ? 'Aggiorna' : 'Salva modulo'}</Text>
                </Pressable>
              </View>
            </>
          )}
        </View>

        {/* DESTRA: Pannello maglie */}
        <View style={styles.rightCol}>
          <Text style={styles.panelTitle}>Maglie da titolare</Text>

          {isReadOnly || (isEditingExisting && available.every((v) => !v)) ? (
            <Text style={{ color: '#6b7280' }}>
              {isReadOnly ? 'Modulo di default · sola lettura' : 'Tutte le maglie sono già in campo'}
            </Text>
          ) : (
            <View style={styles.jerseysWrap}>
              {jerseyIndices.map((i) =>
                available[i] ? (
                  <ShirtButton
                    key={i}
                    label={`${i + 1}`}
                    active={placingIndex === i}
                    disabled={isReadOnly}
                    onPress={() => setPlacingIndex(i)}
                  />
                ) : null
              )}
            </View>
          )}

          {!isEditingExisting && !isReadOnly && (
            <View style={{ marginTop: 12 }}>
              <Text style={styles.helpText}>
                1) Seleziona una maglia → 2) Tocca il campo per posizionarla → 3) Trascina per regolare → 4) Salva
              </Text>
            </View>
          )}

          {/* Nome modulo (solo nuovi o edit custom) */}
          {!isReadOnly && (
            <>
              <Text style={[styles.panelTitle, { marginTop: 12 }]}>Nome modulo</Text>
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="Es. 4-4-1-1 stretta"
                style={styles.input}
              />
            </>
          )}
        </View>
      </View>

      {/* Modal: nome modulo (solo nuovi se manca) */}
      <Modal
        visible={showNameModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowNameModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View className="box" style={styles.modalBox}>
            <Text style={styles.modalTitle}>Nome del modulo</Text>
            <TextInput
              placeholder="Es. 4-4-1-1 stretta"
              style={styles.input}
              value={title}
              onChangeText={setTitle}
            />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Pressable style={[styles.btn, { backgroundColor: '#9ca3af', flex: 1 }]} onPress={() => setShowNameModal(false)}>
                <Text style={styles.btnText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.btn, { backgroundColor: '#1b7f3b', flex: 1 }]}
                onPress={() => {
                  const key = title.trim();
                  if (!key) { Alert.alert('Attenzione', 'Inserisci un nome valido'); return; }
                  if (!allPlaced) { Alert.alert('Mancano maglie', 'Devi posizionare tutte le 11 maglie prima di salvare.'); return; }

                  Alert.alert(
                    'Conferma',
                    `Vuoi salvare il modulo "${key}"?`,
                    [
                      { text: 'Annulla', style: 'cancel' },
                      {
                        text: 'Conferma',
                        style: 'destructive',
                        onPress: async () => {
                          await saveCustomCore(key);
                          setShowNameModal(false);
                          router.replace('/moduli' as Href);
                        },
                      },
                    ],
                    { cancelable: true }
                  );
                }}
              >
                <Text style={styles.btnText}>Salva</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
}

/* --------------------------------- Stili --------------------------------- */
const LINE = 'rgba(255,255,255,0.7)';

const styles = StyleSheet.create({
  container: { flex: 1, flexDirection: 'row', backgroundColor: '#f5f7fa' },
  leftCol: { flex: 7, padding: 12 },
  rightCol: { flex: 3, padding: 12, borderLeftWidth: 1, borderColor: '#e5e7eb', backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: '800', marginBottom: 8 },
  field: {
    width: '100%',
    height: FIELD_H,
    backgroundColor: '#1b7f3b',
    borderRadius: 12,
    borderWidth: 3,
    borderColor: '#0d5f2b',
    overflow: 'hidden',
  },
  midLine: { position: 'absolute', left: 0, right: 0, top: '50%', height: 2, backgroundColor: LINE },
  centerCircle: {
    position: 'absolute', top: '50%', left: '50%', width: 120, height: 120,
    marginLeft: -60, marginTop: -60, borderWidth: 2, borderColor: LINE, borderRadius: 60,
  },
  penaltyBox: { position: 'absolute', width: '60%', height: '18%', left: '20%', borderColor: LINE, borderWidth: 2 },
  sixYardBox: { position: 'absolute', width: '36%', height: '6%', left: '32%', borderColor: LINE, borderWidth: 2 },
  goal: { position: 'absolute', width: '16%', height: 4, left: '42%', backgroundColor: LINE },
  topPenaltyBox: { top: '4%' },
  topSixYard: { top: '4%' },
  topGoal: { top: '1.2%' },
  bottomPenaltyBox: { bottom: '4%' },
  bottomSixYard: { bottom: '4%' },
  bottomGoal: { bottom: '1.2%' },

  counterText: { marginTop: 8, color: '#374151', fontWeight: '700' },

  bottomBar: { flexDirection: 'row', gap: 10, marginTop: 10 },
  btn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  btnText: { color: 'white', fontWeight: '800', textAlign: 'center' },

  panelTitle: { fontSize: 16, fontWeight: '800', marginBottom: 8 },
  jerseysWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },

  // Bottoni "maglia"
  shirtWrap: {
    width: '47%',
    backgroundColor: '#eef2ff',
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#c7d2fe',
    alignItems: 'center',
  },
  shirtActive: { borderColor: '#1b7f3b', backgroundColor: '#e6ffe9' },
  shirtBody: {
    width: 54,
    height: 34,
    flexDirection: 'row',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    overflow: 'hidden',
    marginBottom: 6,
  },
  sleeve: { position: 'absolute', top: 4, width: 14, height: 14, borderRadius: 4, backgroundColor: '#3b82f6' },
  shirtNum: { color: '#0f172a', fontWeight: '900' },
  shirtHint: { color: '#6b7280', fontSize: 11, marginTop: 2 },

  // Maglia sul campo
  fieldShirtBody: {
    width: SHIRT_W,
    height: SHIRT_H,
    flexDirection: 'row',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(0,0,0,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fieldSleeve: { position: 'absolute', top: 6, width: 18, height: 18, borderRadius: 5, backgroundColor: '#3b82f6' },
  fieldShirtNum: { position: 'absolute', color: '#111', fontWeight: '900', fontSize: 12 },

  helpText: { color: '#4b5563', fontStyle: 'italic' },

  // input nome
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 10, backgroundColor: '#fff' },

  // modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '92%', maxWidth: 520, backgroundColor: '#fff', borderRadius: 12, padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10 },
});
