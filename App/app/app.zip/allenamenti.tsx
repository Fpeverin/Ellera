// app/allenamenti.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import {
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import EventEditorModal from './components/EventEditorModal';
import { CalendarEvent, STORAGE_KEY } from './data/events';

interface CalendarDay {
  dateString: string;
  day: number;
  month: number;
  year: number;
  timestamp: number;
}
type WeekKey = 0 | 1 | 2 | 3 | 4 | 5 | 6; // JS getDay(): 0=Dom ... 6=Sab

// Giorni in ordine italiano (Lun→Dom) ma mappati verso getDay()
const IT_DAYS: { label: string; getDay: WeekKey }[] = [
  { label: 'Lunedì', getDay: 1 },
  { label: 'Martedì', getDay: 2 },
  { label: 'Mercoledì', getDay: 3 },
  { label: 'Giovedì', getDay: 4 },
  { label: 'Venerdì', getDay: 5 },
  { label: 'Sabato', getDay: 6 },
  { label: 'Domenica', getDay: 0 },
];

export default function Allenamenti() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [showModal, setShowModal] = useState(false);       // modale "nuovo evento" singolo
  const [showWeekModal, setShowWeekModal] = useState(false); // modale "settimana ideale"
  const router = useRouter();

  // Stato "settimana ideale"
  const [startDate, setStartDate] = useState<string>(''); // YYYY-MM-DD
  const [endDate, setEndDate] = useState<string>('');     // YYYY-MM-DD
  const [location, setLocation] = useState('Campo di allenamento');
  const [weekCfg, setWeekCfg] = useState<Record<WeekKey, { enabled: boolean; time: string }>>({
    1: { enabled: true, time: '18:30' },  // Lunedì
    2: { enabled: false, time: '18:30' }, // Martedì
    3: { enabled: true, time: '18:30' },  // Mercoledì
    4: { enabled: false, time: '18:30' }, // Giovedì
    5: { enabled: false, time: '18:30' }, // Venerdì
    6: { enabled: false, time: '10:00' }, // Sabato
    0: { enabled: false, time: '10:00' }, // Domenica
  });

  // Conferme eliminazione (custom modal → funziona su web)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);
  const [busy, setBusy] = useState(false);

  const loadEvents = async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const list: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    setEvents(list.filter((e) => e.type === 'ALLENAMENTO'));
  };

  useFocusEffect(useCallback(() => { loadEvents(); }, []));

  // util: loop date
  const eachDay = (startISO: string, endISO: string): Date[] => {
    const start = new Date(`${startISO}T00:00:00`);
    const end = new Date(`${endISO}T00:00:00`);
    const out: Date[] = [];
    if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) return out;
    let cur = new Date(start);
    while (cur <= end) {
      out.push(new Date(cur));
      cur.setDate(cur.getDate() + 1);
    }
    return out;
  };

  const fmtDate = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  const canCreateBulk = useMemo(() => {
    if (!startDate || !endDate || !location) return false;
    // almeno un giorno della settimana attivo con orario valido HH:mm
    return IT_DAYS.some(({ getDay }) => {
      const c = weekCfg[getDay];
      return c?.enabled && /^\d{2}:\d{2}$/.test(c.time);
    });
  }, [startDate, endDate, location, weekCfg]);

  const createTrainingsFromWeek = async () => {
    if (!canCreateBulk) return;

    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: CalendarEvent[] = raw ? JSON.parse(raw) : [];

    const days = eachDay(startDate, endDate);
    const toAdd: CalendarEvent[] = [];

    for (const day of days) {
      const dayIdx = day.getDay() as WeekKey; // 0..6
      const cfg = weekCfg[dayIdx];
      if (!cfg?.enabled) continue;

      const dateStr = fmtDate(day);
      const timeStr = cfg.time;

      // dedupe: esiste già un ALLENAMENTO stessa data/ora?
      const exists = all.some(
        (ev) => ev.type === 'ALLENAMENTO' && ev.date === dateStr && ev.time === timeStr
      );
      if (exists) continue;

      toAdd.push({
        id: `${Date.now()}-${dateStr}-${timeStr}-${Math.random().toString(36).slice(2, 6)}`,
        type: 'ALLENAMENTO',
        date: dateStr,
        time: timeStr,
        location,
        presenze: {},
        temaAllenamento: undefined,
        formationSlots: undefined,
        benchIds: [],
        tacticsIds: [],
      });
    }

    if (toAdd.length === 0) {
      setShowWeekModal(false);
      return;
    }

    const updatedAll = [...all, ...toAdd];
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedAll));

    setShowWeekModal(false);
    loadEvents();
  };

  // Eliminazione singolo ALLENAMENTO (conferma via modal custom)
  const actuallyDeleteOne = async () => {
    if (!confirmDeleteId) return;
    setBusy(true);
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    const updated = all.filter((ev) => ev.id !== confirmDeleteId);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setBusy(false);
    setConfirmDeleteId(null);
    loadEvents();
  };

  // Eliminazione di TUTTI gli ALLENAMENTI
  const actuallyDeleteAllTrainings = async () => {
    setBusy(true);
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const all: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    const keep = all.filter((ev) => ev.type !== 'ALLENAMENTO'); // mantieni solo NON-allenamenti
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(keep));
    setBusy(false);
    setConfirmDeleteAll(false);
    loadEvents();
  };

  // --- gestione mini calendario (range picker) ---
  const onDayPress = (day: CalendarDay) => {
    const d = day.dateString; // YYYY-MM-DD
    if (!startDate || (startDate && endDate)) {
      setStartDate(d);
      setEndDate('');
    } else {
      if (d < startDate) {
        setStartDate(d);
        setEndDate('');
      } else {
        setEndDate(d);
      }
    }
  };

  const markedDates = useMemo(() => {
    const marks: Record<string, any> = {};
    if (startDate && !endDate) {
      marks[startDate] = { startingDay: true, endingDay: true, color: '#1b7f3b', textColor: 'white' };
      return marks;
    }
    if (startDate && endDate) {
      const days = eachDay(startDate, endDate);
      days.forEach((date, idx) => {
        const ds = fmtDate(date);
        if (idx === 0) {
          marks[ds] = { startingDay: true, color: '#1b7f3b', textColor: 'white' };
        } else if (idx === days.length - 1) {
          marks[ds] = { endingDay: true, color: '#1b7f3b', textColor: 'white' };
        } else {
          marks[ds] = { color: '#49a86a', textColor: 'white' };
        }
      });
    }
    return marks;
  }, [startDate, endDate]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tutti gli Allenamenti</Text>

      {/* Azioni top: Rimuovi tutti */}
      <View style={styles.topActions}>
        <Pressable style={[styles.actionBtnOutline]} onPress={() => setConfirmDeleteAll(true)}>
          <Text style={styles.actionOutlineText}>🧹 Rimuovi tutti</Text>
        </Pressable>
      </View>

      <FlatList
        data={[...events].sort((a, b) => a.date.localeCompare(b.date))}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text>Nessun allenamento trovato</Text>}
        renderItem={({ item }) => (
          <View style={styles.eventCard}>
            <Pressable style={{ flex: 1 }} onPress={() => router.push(`/eventi/allenamento/${item.id}`)}>
              <Text style={styles.eventTitle}>{item.location}</Text>
              <Text>
                {item.date} · {item.time}
              </Text>
            </Pressable>
            <Pressable style={styles.trashBtn} onPress={() => setConfirmDeleteId(item.id)}>
              <Text style={{ fontSize: 18 }}>🗑️</Text>
            </Pressable>
          </View>
        )}
      />

      {/* Azioni bottom: Nuovo singolo + Settimana ideale */}
      <View style={styles.actionsRow}>
        <Pressable
          style={[styles.actionBtn, { backgroundColor: '#1b4f7f' }]}
          onPress={() => setShowModal(true)}
        >
          <Text style={styles.actionText}>+ Nuovo</Text>
        </Pressable>

        <Pressable
          style={[styles.actionBtn, { backgroundColor: '#1b7f3b' }]}
          onPress={() => setShowWeekModal(true)}
        >
          <Text style={styles.actionText}>Settimana ideale</Text>
        </Pressable>
      </View>

      {/* Modale "nuovo" (riutilizzo editor standard) */}
      <EventEditorModal
        visible={showModal}
        initialType="ALLENAMENTO"
        onClose={() => setShowModal(false)}
        onSaved={loadEvents}
      />

      {/* Modale "Settimana ideale" */}
      <Modal
        visible={showWeekModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowWeekModal(false)}
      >
        <View style={styles.overlay}>
          <View style={styles.sheet}>
            <Text style={styles.modalTitle}>Settimana ideale</Text>
            <ScrollView contentContainerStyle={{ paddingBottom: 16 }}>
              {/* MINI CALENDARIO: range start/end */}
              <Text style={styles.label}>Periodo</Text>
              <Calendar
                onDayPress={onDayPress}
                markedDates={markedDates}
                markingType="period"
                theme={{
                  selectedDayBackgroundColor: '#1b7f3b',
                  todayTextColor: '#1b7f3b',
                }}
              />
              <View style={styles.rangeRow}>
                <Text style={{ fontWeight: '700' }}>Inizio:</Text>
                <Text style={{ marginLeft: 6 }}>{startDate || '-'}</Text>
                <Text style={{ marginLeft: 12, fontWeight: '700' }}>Fine:</Text>
                <Text style={{ marginLeft: 6 }}>{endDate || '-'}</Text>
              </View>

              {/* Luogo unico per tutti i nuovi eventi */}
              <Text style={styles.label}>Luogo</Text>
              <TextInput
                value={location}
                onChangeText={setLocation}
                placeholder="Campo di allenamento"
                style={styles.input}
              />

              {/* Giorni/orari */}
              <Text style={[styles.label, { marginTop: 12 }]}>Giorni & orari</Text>
              {IT_DAYS.map(({ label, getDay }) => {
                const cfg = weekCfg[getDay];
                return (
                  <View key={getDay} style={styles.dayRow}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 }}>
                      <Switch
                        value={cfg.enabled}
                        onValueChange={(v) =>
                          setWeekCfg((prev) => ({ ...prev, [getDay]: { ...prev[getDay], enabled: v } }))
                        }
                      />
                      <Text style={{ fontWeight: '600' }}>{label}</Text>
                    </View>
                    <TextInput
                      value={cfg.time}
                      onChangeText={(t) =>
                        setWeekCfg((prev) => ({ ...prev, [getDay]: { ...prev[getDay], time: t } }))
                      }
                      placeholder="HH:mm"
                      style={[styles.input, { width: 90 }]}
                      autoCapitalize="none"
                    />
                  </View>
                );
              })}

              <View style={{ height: 12 }} />

              {/* CTA */}
              <Pressable
                style={[styles.createBtn, !canCreateBulk && { opacity: 0.6 }]}
                onPress={createTrainingsFromWeek}
                disabled={!canCreateBulk}
              >
                <Text style={styles.createText}>CREA ALLENAMENTI</Text>
              </Pressable>

              <Pressable style={styles.cancelBtn} onPress={() => setShowWeekModal(false)}>
                <Text style={styles.cancelText}>Chiudi</Text>
              </Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* MODALE CONFERMA: elimina SINGOLO */}
      <Modal visible={!!confirmDeleteId} transparent animationType="fade" onRequestClose={() => setConfirmDeleteId(null)}>
        <View style={styles.confirmOverlay}>
          <View style={styles.confirmCard}>
            <Text style={styles.confirmTitle}>Eliminare questo allenamento?</Text>
            <View style={styles.confirmRow}>
              <Pressable style={[styles.confirmBtn, styles.confirmCancel]} onPress={() => setConfirmDeleteId(null)}>
                <Text style={styles.confirmCancelText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.confirmBtn, styles.confirmDelete, busy && { opacity: 0.6 }]}
                onPress={actuallyDeleteOne}
                disabled={busy}
              >
                <Text style={styles.confirmDeleteText}>Elimina</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* MODALE CONFERMA: elimina TUTTI */}
      <Modal visible={confirmDeleteAll} transparent animationType="fade" onRequestClose={() => setConfirmDeleteAll(false)}>
        <View style={styles.confirmOverlay}>
          <View style={styles.confirmCard}>
            <Text style={styles.confirmTitle}>Eliminare TUTTI gli allenamenti?</Text>
            <View style={styles.confirmRow}>
              <Pressable style={[styles.confirmBtn, styles.confirmCancel]} onPress={() => setConfirmDeleteAll(false)}>
                <Text style={styles.confirmCancelText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.confirmBtn, styles.confirmDelete, busy && { opacity: 0.6 }]}
                onPress={actuallyDeleteAllTrainings}
                disabled={busy}
              >
                <Text style={styles.confirmDeleteText}>Elimina tutti</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },

  topActions: { marginBottom: 8, flexDirection: 'row', justifyContent: 'flex-end' },
  actionBtnOutline: {
    paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8, borderWidth: 1, borderColor: '#b91c1c',
  },
  actionOutlineText: { color: '#b91c1c', fontWeight: '800' },

  eventCard: {
    backgroundColor: '#eee',
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  eventTitle: { fontWeight: '700', marginBottom: 2, color: '#111' },
  trashBtn: {
    paddingVertical: 6, paddingHorizontal: 8, backgroundColor: '#fff', borderRadius: 8,
    borderWidth: 1, borderColor: '#ddd',
  },

  actionsRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  actionBtn: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  actionText: { color: '#fff', fontWeight: '700' },

  // Modale settimana ideale
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  sheet: { backgroundColor: 'white', borderRadius: 10, width: '92%', maxHeight: '92%', padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10 },

  label: { fontWeight: '700', marginTop: 8 },
  input: {
    borderWidth: 1, borderColor: '#ccc', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8, marginTop: 6,
    backgroundColor: 'white',
  },

  dayRow: {
    marginTop: 8,
    backgroundColor: '#f3f4f6',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  rangeRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },

  createBtn: { backgroundColor: '#1b7f3b', padding: 12, borderRadius: 8, alignItems: 'center' },
  createText: { color: 'white', fontWeight: '800' },
  cancelBtn: { marginTop: 8, padding: 10, borderRadius: 8, alignItems: 'center', backgroundColor: '#ddd' },
  cancelText: { fontWeight: '700' },

  // Conferme eliminazione
  confirmOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center' },
  confirmCard: { backgroundColor: 'white', borderRadius: 10, width: '86%', padding: 16 },
  confirmTitle: { fontSize: 16, fontWeight: '800', marginBottom: 12 },
  confirmRow: { flexDirection: 'row', gap: 8 },
  confirmBtn: { flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  confirmCancel: { backgroundColor: '#e5e7eb' },
  confirmCancelText: { fontWeight: '700', color: '#111' },
  confirmDelete: { backgroundColor: '#b91c1c' },
  confirmDeleteText: { fontWeight: '800', color: 'white' },
});
