// app/data/players.ts
export type Role = 'PORTIERE' | 'DIFENSORE' | 'CENTROCAMPISTA' | 'ATTACCANTE';

export type Player = {
  id: string;
  name: string;
  height: string;
  weight: string;        // Nome e cognome
  year: number;
  role: Role;
  photo?: string | null;      // uri locale o http
  attachments?: { name: string; uri: string }[];
};

export const players: Player[] = [
  // PORTIERI
  { id: 'beccari-gabriele', name: 'BECCARI GABRIELE', year: 2008, role: 'PORTIERE', height: '170', weight: '60' },
  { id: 'segoloni-riccardo', name: 'SEGOLONI RICCARDO', year: 1988, role: 'PORTIERE', height: '170', weight: '60' },
  { id: 'liuzza-alessandro', name: 'LIUZZA ALESSANDRO', year: 2007, role: 'PORTIERE', height: '170', weight: '60' },

  // DIFENSORI
  { id: 'polidori-mattia', name: 'POLIDORI MATTIA', year: 1998, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'morlunghi-alessandro', name: 'MORLUNGHI ALESSANDRO', year: 2005, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'mottola-francesco', name: 'MOTTOLA FRANCESCO', year: 2005, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'vescovi-filippo', name: 'VESCOVI FILIPPO', year: 2005, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'sorbelli-daniele', name: 'SORBELLI DANIELE', year: 2002, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'tarpani-matteo', name: 'TARPANI MATTEO', year: 2006, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'bolletta-marco', name: 'BOLLETTA MARCO', year: 1993, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'giombetti-daniele', name: 'GIOMBETTI DANIELE', year: 2007, role: 'DIFENSORE', height: '170', weight: '60' },
  { id: 'silvestri-giacomo', name: 'SILVESTRI GIACOMO', year: 2008, role: 'DIFENSORE', height: '170', weight: '60' },

  // CENTROCAMPISTI
  { id: 'salvucci-thomas', name: 'SALVUCCI THOMAS', year: 1998, role: 'CENTROCAMPISTA', height: '170', weight: '60' },
  { id: 'convito-michele', name: 'CONVITO MICHELE', year: 2002, role: 'CENTROCAMPISTA', height: '170', weight: '60' },
  { id: 'paradisi-filippo', name: 'PARADISI FILIPPO', year: 1998, role: 'CENTROCAMPISTA', height: '170', weight: '60' },
  { id: 'federico-polidoro', name: 'FEDERICO POLIDORO', year: 2002, role: 'CENTROCAMPISTA', height: '170', weight: '60' },
  { id: 'roticiani-tommaso', name: 'ROTICIANI TOMMASO', year: 2008, role: 'CENTROCAMPISTA', height: '170', weight: '60' },
  { id: 'sisani-alessio', name: 'SISANI ALESSIO', year: 2007, role: 'CENTROCAMPISTA', height: '170', weight: '60' },

  // ATTACCANTI
  { id: 'ravanelli-carlo', name: 'RAVANELLI CARLO', year: 2005, role: 'ATTACCANTE', height: '170', weight: '60' },
  { id: 'vinciarelli-daniele', name: 'VINCIARELLI DANIELE', year: 2002, role: 'ATTACCANTE', height: '170', weight: '60' },
  { id: 'nuti-francesco', name: 'NUTI FRANCESCO', year: 2006, role: 'ATTACCANTE', height: '170', weight: '60' },
  { id: 'mariotti-francesco', name: 'MARIOTTI FRANCESCO', year: 2006, role: 'ATTACCANTE', height: '170', weight: '60' },
  { id: 'massetti-giovanni', name: 'MASSETTI GIOVANNI', year: 2007, role: 'ATTACCANTE', height: '170', weight: '60' },
  { id: 'mantovani-filippo', name: 'MANTOVANI FILIPPO', year: 2008, role: 'ATTACCANTE', height: '170', weight: '60' },
];
