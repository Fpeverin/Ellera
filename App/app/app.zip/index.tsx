// app/index.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import EventEditorModal from './components/EventEditorModal';
import { CalendarEvent, STORAGE_KEY } from './data/events';

/* ------------------ Helpers date in fuso locale (no UTC) ------------------ */
function pad2(n: number) {
  return String(n).padStart(2, '0');
}
function fmtYMDLocal(d: Date) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function parseYMDTimeLocal(ymd: string, hhmm = '00:00') {
  const [y, m, day] = ymd.split('-').map(Number);
  const [hh, mm] = (hhmm || '00:00').split(':').map(Number);
  return new Date(y, (m ?? 1) - 1, day ?? 1, hh ?? 0, mm ?? 0, 0, 0);
}

/* ------------------------------ Component ------------------------------ */
export default function Dashboard() {
  const router = useRouter();

  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [initialDateForModal, setInitialDateForModal] = useState<string | undefined>(undefined);

  const loadEvents = async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const list: CalendarEvent[] = raw ? JSON.parse(raw) : [];
    // ordina per data/ora
    list.sort(
      (a, b) =>
        parseYMDTimeLocal(a.date, a.time || '00:00').getTime() -
        parseYMDTimeLocal(b.date, b.time || '00:00').getTime()
    );
    setEvents(list);
  };

  useFocusEffect(
    useCallback(() => {
      loadEvents();
    }, [])
  );

  /* --------------------- Mappa: eventi per data (YYYY-MM-DD) --------------------- */
  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const ev of events) {
      const arr = map.get(ev.date) ?? [];
      arr.push(ev);
      map.set(ev.date, arr);
    }
    return map;
  }, [events]);

  /* ---------------------------- Eventi futuri ---------------------------- */
  const now = new Date();
  const upcomingEvents = useMemo(
    () =>
      events
        .filter((ev) => parseYMDTimeLocal(ev.date, ev.time || '00:00') >= now)
        .sort(
          (a, b) =>
            parseYMDTimeLocal(a.date, a.time || '00:00').getTime() -
            parseYMDTimeLocal(b.date, b.time || '00:00').getTime()
        ),
    [events]
  );

  /* ---------------------- Format e colori delle pill ---------------------- */
  const pillColor = (ev: CalendarEvent) => (ev.type === 'PARTITA' ? '#e74c3c' : '#1b7f3b');

  const formatEventPill = (ev: CalendarEvent) => {
    if (ev.type === 'ALLENAMENTO') {
      const tema = ev.temaAllenamento ? ` · ${ev.temaAllenamento}` : '';
      const comp = (ev as any).competition ? ` · ${(ev as any).competition}` : '';
      return `Allenamento${tema}${comp}`;
    }
    const opp = ev.opponent || 'Avversario';
    const ha = (ev as any).homeAway as 'CASA' | 'TRASFERTA' | undefined;
    const titolo = ha === 'TRASFERTA' ? `${opp} - Ellera` : `Ellera - ${opp}`;
    const comp = (ev as any).competition ? ` · ${(ev as any).competition}` : '';
    return `${titolo}${comp}`;
  };

  const formatEventCardTitle = (ev: CalendarEvent) =>
    ev.type === 'PARTITA'
      ? formatEventPill(ev)
      : formatEventPill(ev);

  /* ------------------------- Griglia calendario (6x7) ------------------------- */
  const renderMonthGrid = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const firstDay = new Date(currentYear, currentMonth, 1);
    const startDate = new Date(firstDay);
    // settimana che inizia di Lunedì
    const weekday = firstDay.getDay() === 0 ? 7 : firstDay.getDay(); // 1..7
    startDate.setDate(startDate.getDate() - (weekday - 1));

    const cells: JSX.Element[] = [];
    const cursor = new Date(startDate);

    for (let i = 0; i < 42; i++) {
      const d = cursor.getDate();
      const isCurrentMonth = cursor.getMonth() === currentMonth;
      const isToday = fmtYMDLocal(cursor) === fmtYMDLocal(today);
      const dateStr = fmtYMDLocal(cursor);
      const list = eventsByDate.get(dateStr) || [];

      const topTwo = list.slice(0, 2);
      const more = list.length - topTwo.length;

      cells.push(
        <Pressable
          key={dateStr}
          style={[styles.dayCell, !isCurrentMonth && styles.otherMonth, isToday && styles.todayCell]}
          onPress={() => {
            setInitialDateForModal(dateStr);
            setShowModal(true);
          }}
        >
          <Text
            style={[
              styles.dayNumber,
              !isCurrentMonth && styles.otherMonthText,
              isToday && styles.todayNumber,
            ]}
          >
            {d}
          </Text>

          <View style={styles.pillsWrap}>
            {topTwo.map((ev) => (
              <View key={ev.id} style={[styles.pill, { backgroundColor: pillColor(ev) }]}>
                <Text style={styles.pillText} numberOfLines={1}>
                  {formatEventPill(ev)}
                </Text>
              </View>
            ))}
            {more > 0 && (
              <View style={[styles.pill, styles.morePill]}>
                <Text style={[styles.pillText, { color: '#111' }]}>+{more}</Text>
              </View>
            )}
          </View>
        </Pressable>
      );

      cursor.setDate(cursor.getDate() + 1);
    }

    return cells;
  };

  /* --------------------------------- Render --------------------------------- */
  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Dashboard Calcistica</Text>
      </View>

      {/* Calendario */}
      <View style={styles.calendarSection}>
        <Text style={styles.sectionTitle}>Calendario</Text>
        <View style={styles.miniCalendar}>
          <Text style={styles.monthTitle}>
            {new Date().toLocaleDateString('it-IT', { month: 'long', year: 'numeric' })}
          </Text>

          {/* Giorni settimana */}
          <View style={styles.weekDays}>
            {['L', 'M', 'M', 'G', 'V', 'S', 'D'].map((d, i) => (
              <Text key={i} style={styles.weekDay}>
                {d}
              </Text>
            ))}
          </View>

          {/* Griglia 6x7 */}
          <View style={styles.daysGrid}>{renderMonthGrid()}</View>

          <Text style={styles.calendarInfo}>
            {events.length} eventi totali ·{' '}
            {
              events.filter((ev) => parseYMDTimeLocal(ev.date, ev.time || '00:00') >= new Date())
                .length
            }{' '}
            futuri
          </Text>
        </View>
      </View>

      {/* Eventi futuri */}
      <View style={styles.eventsSection}>
        <Text style={styles.sectionTitle}>Eventi futuri</Text>
        <FlatList
          data={upcomingEvents}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          ListEmptyComponent={<Text style={styles.emptyText}>Nessun evento futuro</Text>}
          renderItem={({ item }) => (
            <Pressable
              style={styles.eventCard}
              onPress={() => {
                if (item.type === 'PARTITA') {
                  // Apri direttamente live della partita
                  // NB: rotta attesa: /eventi/partita/[id]
                  // altrimenti sostituisci con la tua
                  // es: router.push(`/eventi/partita/${item.id}`);
                  // Se la tua live è direttamente [id]/live:
                  // router.push(`/eventi/partita/${item.id}/live`);
                  // In base a quanto avete impostato:
                  // (uso la root già condivisa da te)
                  // @ts-ignore
                  router.push(`/eventi/partita/${item.id}`);
                } else {
                  router.push(`/eventi/allenamento/${item.id}`);
                }
              }}
            >
              <View style={styles.eventHeader}>
                <Text
                  style={[
                    styles.eventType,
                    { backgroundColor: item.type === 'PARTITA' ? '#e74c3c' : '#1b7f3b' },
                  ]}
                >
                  {item.type}
                </Text>
                <Text style={styles.eventDate}>{item.date}</Text>
              </View>
              <Text style={styles.eventTitle}>{formatEventCardTitle(item)}</Text>
              <Text style={styles.eventDetails}>
                {item.time || '--:--'} · {item.location}
              </Text>
            </Pressable>
          )}
        />
      </View>

      {/* Azioni rapide */}
      <View style={styles.actionsSection}>
        <Text style={styles.sectionTitle}>Azioni rapide</Text>
        <View style={styles.actions}>
          <Pressable style={styles.actionButton} onPress={() => router.push('/calendario')}>
            <Text style={styles.actionIcon}>📅</Text>
            <Text style={styles.actionText}>Eventi</Text>
          </Pressable>
          <Pressable style={styles.actionButton} onPress={() => router.push('/squadra')}>
            <Text style={styles.actionIcon}>👥</Text>
            <Text style={styles.actionText}>Gestione Squadra</Text>
          </Pressable>
          <Pressable style={styles.actionButton} onPress={() => router.push('/partite')}>
            <Text style={styles.actionIcon}>🏆</Text>
            <Text style={styles.actionText}>Partite</Text>
          </Pressable>
          <Pressable style={styles.actionButton} onPress={() => router.push('/allenamenti')}>
            <Text style={styles.actionIcon}>🏃</Text>
            <Text style={styles.actionText}>Allenamenti</Text>
          </Pressable>
        </View>
      </View>

      {/* Modale Nuovo evento (solo clic sul calendario, con data preselezionata) */}
      <EventEditorModal
        visible={showModal}
        onClose={() => setShowModal(false)}
        onSaved={loadEvents}
        initialDate={initialDateForModal}
      />
    </ScrollView>
  );
}

/* --------------------------------- Stili --------------------------------- */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f7fa' },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    marginBottom: 20,
  },
  title: { fontSize: 28, fontWeight: '700', color: '#1a202c' },

  sectionTitle: { fontSize: 20, fontWeight: '700', color: '#1a202c', marginBottom: 12 },

  // Calendario
  calendarSection: { paddingHorizontal: 16, marginBottom: 24 },
  miniCalendar: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  monthTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1a202c',
    textAlign: 'center',
    marginBottom: 16,
    textTransform: 'capitalize',
  },
  weekDays: { flexDirection: 'row', marginBottom: 8 },
  weekDay: {
    flex: 1,
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    paddingVertical: 8,
  },

  daysGrid: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 12 },
  dayCell: {
    width: '14.28571%',
    aspectRatio: 1,
    position: 'relative',
    paddingTop: 6,
    paddingHorizontal: 4,
  },
  dayNumber: { fontSize: 12, color: '#1a202c', fontWeight: '700' },
  todayCell: { borderWidth: 1, borderColor: '#1b7f3b', borderRadius: 8 },
  todayNumber: { color: '#1b7f3b' },
  otherMonth: { opacity: 0.35 },
  otherMonthText: { color: '#999' },

  pillsWrap: { marginTop: 4, gap: 2 },
  pill: { borderRadius: 4, paddingHorizontal: 4, paddingVertical: 2, minHeight: 18 },
  pillText: { color: 'white', fontSize: 10, fontWeight: '700' },
  morePill: { backgroundColor: '#e5e7eb' },

  calendarInfo: { fontSize: 14, color: '#666', textAlign: 'center', marginTop: 8 },

  // Eventi futuri
  eventsSection: { paddingHorizontal: 16, marginBottom: 24 },
  eventCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  eventHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  eventType: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    textTransform: 'uppercase',
  },
  eventDate: { fontSize: 14, color: '#666', fontWeight: '500' },
  eventTitle: { fontSize: 16, fontWeight: '700', marginBottom: 4, color: '#1a202c' },
  eventDetails: { fontSize: 14, color: '#666' },
  emptyText: { color: '#666', textAlign: 'center', fontStyle: 'italic', paddingVertical: 20 },

  // Bottoni
  actionsSection: { paddingHorizontal: 16, marginBottom: 24 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  actionButton: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  actionIcon: { fontSize: 24, marginBottom: 8 },
  actionText: { fontSize: 14, fontWeight: '600', color: '#1a202c', textAlign: 'center' },
});
