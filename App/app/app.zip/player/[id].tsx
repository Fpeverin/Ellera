// app/player/[id].tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import * as Linking from 'expo-linking';
import { useLocalSearchParams, useNavigation } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { CalendarEvent, STORAGE_KEY } from '../data/events';
import { Player, players } from '../data/players';

const PHOTO_KEY = 'players/photos';
const ATTACH_KEY_PREFIX = 'players/attachments/';
const INJURY_KEY_PREFIX = 'players/injuries/';

type TabKey = 'PARTITE' | 'ALLENAMENTI' | 'INFORTUNI' | 'ALLEGATI';

type CalendarDay = {
  dateString: string; // YYYY-MM-DD
  day: number;
  month: number;
  year: number;
  timestamp: number;
};

type Injury = {
  id: string;
  from: string;        // YYYY-MM-DD
  to?: string;         // YYYY-MM-DD
  type: string;        // es. Strappo, Distorsione, Contusione
  note?: string;
};

export default function PlayerDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const navigation = useNavigation();

  const base = players.find(p => p.id === id) as Player | undefined;

  const [tab, setTab] = useState<TabKey>('PARTITE');

  // Foto / allegati
  const [photo, setPhoto] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<{ name: string; uri: string }[]>([]);

  // STATISTICHE ALLENAMENTI
  const [trainingsTotal, setTrainingsTotal] = useState(0);
  const [trainingsPresent, setTrainingsPresent] = useState(0);
  const [recentTrend, setRecentTrend] = useState<boolean[]>([]); // ultimi 5 (true=presente)
  const [monthlySummary, setMonthlySummary] = useState<{ month: string; present: number; total: number }[]>([]);

  // INFORTUNI
  const [injuries, setInjuries] = useState<Injury[]>([]);
  const [injuryModal, setInjuryModal] = useState(false);
  const [editIdx, setEditIdx] = useState<number | null>(null);
  const [injFrom, setInjFrom] = useState<string>('');
  const [injTo, setInjTo] = useState<string>('');
  const [injType, setInjType] = useState<string>('');
  const [injNote, setInjNote] = useState<string>('');
  const [pickWhichDate, setPickWhichDate] = useState<'FROM' | 'TO' | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: base?.name ?? 'Giocatore' });
  }, [navigation, base?.name]);

  // Carica foto + allegati + infortuni
  useEffect(() => {
    (async () => {
      try {
        const photosRaw = await AsyncStorage.getItem(PHOTO_KEY);
        if (photosRaw) {
          const map = JSON.parse(photosRaw);
          if (map[id!]) setPhoto(map[id!]);
        }
        const attRaw = await AsyncStorage.getItem(ATTACH_KEY_PREFIX + id);
        if (attRaw) setAttachments(JSON.parse(attRaw));

        const injRaw = await AsyncStorage.getItem(INJURY_KEY_PREFIX + id);
        if (injRaw) setInjuries(JSON.parse(injRaw));
      } catch (e) {
        console.warn('Errore caricamento dati giocatore', e);
      }
    })();
  }, [id]);

  // Statistiche allenamenti
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        const list: CalendarEvent[] = raw ? JSON.parse(raw) : [];
        const allenamenti = list
          .filter(ev => ev.type === 'ALLENAMENTO')
          .sort((a, b) => `${a.date} ${a.time || '00:00'}`.localeCompare(`${b.date} ${b.time || '00:00'}`));

        const total = allenamenti.length;
        const present = allenamenti.filter(ev => !!ev.presenze?.[id!]).length;

        const last5 = allenamenti.slice(-5);
        const trend = last5.map(ev => !!ev.presenze?.[id!]);

        const monthMap = new Map<string, { present: number; total: number }>();
        for (const ev of allenamenti) {
          const month = (ev.date || '').slice(0, 7) || 'N/D';
          const entry = monthMap.get(month) ?? { present: 0, total: 0 };
          entry.total += 1;
          if (ev.presenze?.[id!]) entry.present += 1;
          monthMap.set(month, entry);
        }
        const monthly = Array.from(monthMap.entries())
          .map(([month, val]) => ({ month, present: val.present, total: val.total }))
          .sort((a, b) => a.month.localeCompare(b.month));

        setTrainingsTotal(total);
        setTrainingsPresent(present);
        setRecentTrend(trend);
        setMonthlySummary(monthly);
      } catch (e) {
        console.warn('Errore calcolo statistiche presenze', e);
      }
    })();
  }, [id]);

  const presencePct = useMemo(() => {
    if (trainingsTotal === 0) return 0;
    return Math.round((trainingsPresent / trainingsTotal) * 100);
  }, [trainingsPresent, trainingsTotal]);

  // --- gestione foto ---
  const savePhoto = async (uri: string | null) => {
    try {
      const photosRaw = await AsyncStorage.getItem(PHOTO_KEY);
      const map = photosRaw ? JSON.parse(photosRaw) : {};
      map[id!] = uri;
      await AsyncStorage.setItem(PHOTO_KEY, JSON.stringify(map));
      setPhoto(uri);
    } catch (e) {
      Alert.alert('Errore', 'Impossibile salvare la foto');
    }
  };

  const pickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permessi', 'Serve il permesso per accedere alle foto.');
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.9,
    });
    if (!res.canceled) {
      savePhoto(res.assets[0].uri);
    }
  };

  // --- gestione allegati ---
  const addAttachment = async () => {
    const res = await DocumentPicker.getDocumentAsync({
      copyToCacheDirectory: true,
      multiple: false,
    });
    if (!res.canceled && res.assets?.length) {
      const file = res.assets[0];
      const newAtts = [...attachments, { name: file.name ?? 'Senza nome', uri: file.uri }];
      setAttachments(newAtts);
      await AsyncStorage.setItem(ATTACH_KEY_PREFIX + id, JSON.stringify(newAtts));
    }
  };

  const removeAttachment = async (uri: string) => {
    const newAtts = attachments.filter(a => a.uri !== uri);
    setAttachments(newAtts);
    await AsyncStorage.setItem(ATTACH_KEY_PREFIX + id, JSON.stringify(newAtts));
  };

  const openAttachment = async (uri: string) => {
    // se è http(s) apri in WebBrowser, altrimenti Linking (file://)
    if (/^https?:\/\//i.test(uri)) {
      await WebBrowser.openBrowserAsync(uri);
    } else {
      await Linking.openURL(uri);
    }
  };

  // --- gestione infortuni ---
  const saveInjuries = async (arr: Injury[]) => {
    setInjuries(arr);
    await AsyncStorage.setItem(INJURY_KEY_PREFIX + id, JSON.stringify(arr));
  };

  const openNewInjury = () => {
    setEditIdx(null);
    setInjFrom('');
    setInjTo('');
    setInjType('');
    setInjNote('');
    setInjuryModal(true);
  };

  const openEditInjury = (index: number) => {
    const inj = injuries[index];
    setEditIdx(index);
    setInjFrom(inj.from);
    setInjTo(inj.to || '');
    setInjType(inj.type);
    setInjNote(inj.note || '');
    setInjuryModal(true);
  };

  const deleteInjury = async (index: number) => {
    const arr = [...injuries];
    arr.splice(index, 1);
    await saveInjuries(arr);
  };

  const canSaveInjury = injFrom && injType;

  const persistInjury = async () => {
    if (!canSaveInjury) return;
    const item: Injury = {
      id: editIdx !== null ? injuries[editIdx].id : `${Date.now()}`,
      from: injFrom,
      to: injTo || undefined,
      type: injType.trim(),
      note: injNote.trim() || undefined,
    };
    const arr = [...injuries];
    if (editIdx !== null) {
      arr[editIdx] = item;
    } else {
      arr.push(item);
    }
    await saveInjuries(arr);
    setInjuryModal(false);
  };

  if (!base) {
    return (
      <View style={styles.center}>
        <Text>Giocatore non trovato.</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 24 }}
      stickyHeaderIndices={[0]} // header fisso
    >
      {/* HEADER FISSO: Foto + info generali */}
      <View style={styles.stickyHeader}>
        <View style={styles.headerRow}>
          {photo ? (
            <Image source={{ uri: photo }} style={styles.photo} />
          ) : (
            <View style={styles.placeholder}>
              <Text style={{ fontSize: 32 }}>👤</Text>
            </View>
          )}
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={styles.name}>{base.name}</Text>
            <Text>Anno: {base.year}</Text>
            {'height' in base && base.height ? <Text>Altezza: {base.height} cm</Text> : null}
            {'weight' in base && base.weight ? <Text>Peso: {base.weight} kg</Text> : null}
          </View>
        </View>
        <View style={styles.headerActions}>
          <Pressable style={styles.actionBtn} onPress={pickPhoto}>
            <Text style={styles.actionText}>{photo ? 'Cambia foto' : 'Aggiungi foto'}</Text>
          </Pressable>
        </View>

        {/* TAB BAR */}
        <View style={styles.tabRow}>
          {(['PARTITE', 'ALLENAMENTI', 'INFORTUNI', 'ALLEGATI'] as TabKey[]).map(k => (
            <Pressable
              key={k}
              style={[styles.tabBtn, tab === k && styles.tabBtnActive]}
              onPress={() => setTab(k)}
            >
              <Text style={[styles.tabText, tab === k && styles.tabTextActive]}>
                {k === 'PARTITE' ? 'Partite'
                  : k === 'ALLENAMENTI' ? 'Allenamenti'
                  : k === 'INFORTUNI' ? 'Storico infortuni'
                  : 'Allegati'}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* CONTENUTO TABS */}
      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        {tab === 'PARTITE' && (
          <View>
            <Text style={styles.sectionTitle}>Partite</Text>
            <Text style={{ color: '#555', marginTop: 4 }}>
              Questa sezione mostrerà le partite giocate dal giocatore (presenze, minuti, gol, ecc.). La popoleremo più avanti.
            </Text>
          </View>
        )}

        {tab === 'ALLENAMENTI' && (
          <View>
            <Text style={styles.sectionTitle}>Statistiche Allenamenti</Text>

            <View style={stylesCard.card}>
              <Text style={stylesCard.title}>Presenze</Text>
              <Text style={stylesCard.value}>
                {trainingsPresent} / {trainingsTotal}
                {trainingsTotal > 0 ? `  (${presencePct}%)` : ''}
              </Text>

              <View style={{ marginTop: 10 }}>
                <Text style={stylesCard.subtitle}>Ultimi 5 allenamenti</Text>
                <View style={stylesCard.trendRow}>
                  {recentTrend.length === 0 ? (
                    <Text style={{ color: '#555' }}>Nessun dato</Text>
                  ) : (
                    recentTrend.map((ok, idx) => (
                      <View key={idx} style={[stylesCard.dot, ok ? stylesCard.dotOk : stylesCard.dotKo]} />
                    ))
                  )}
                </View>
              </View>

              <View style={{ marginTop: 12 }}>
                <Text style={stylesCard.subtitle}>Riepilogo mensile</Text>
                {monthlySummary.length === 0 ? (
                  <Text style={{ color: '#555' }}>Nessun allenamento registrato</Text>
                ) : (
                  monthlySummary.map(m => (
                    <View key={m.month} style={stylesCard.monthRow}>
                      <Text style={{ flex: 1 }}>{m.month}</Text>
                      <Text style={{ fontWeight: '700' }}>
                        {m.present}/{m.total} {m.total > 0 ? `(${Math.round((m.present / m.total) * 100)}%)` : ''}
                      </Text>
                    </View>
                  ))
                )}
              </View>
            </View>
          </View>
        )}

        {tab === 'INFORTUNI' && (
          <View>
            <Text style={styles.sectionTitle}>Storico infortuni</Text>
            <Pressable style={[styles.actionBtn, { backgroundColor: '#1b7f3b', alignSelf: 'flex-start' }]} onPress={openNewInjury}>
              <Text style={styles.actionText}>+ Nuovo infortunio</Text>
            </Pressable>

            {injuries.length === 0 ? (
              <Text style={{ color: '#555', marginTop: 8 }}>Nessun infortunio registrato</Text>
            ) : (
              <View style={{ marginTop: 8, gap: 8 }}>
                {injuries
                  .slice()
                  .sort((a, b) => (a.from || '').localeCompare(b.from || ''))
                  .map((inj, idx) => (
                    <View key={inj.id} style={styles.injuryRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontWeight: '800' }}>{inj.type}</Text>
                        <Text style={{ color: '#374151' }}>
                          {inj.from} {inj.to ? `→ ${inj.to}` : '(in corso)'}
                        </Text>
                        {inj.note ? <Text style={{ color: '#374151' }}>Note: {inj.note}</Text> : null}
                      </View>
                      <View style={{ flexDirection: 'row', gap: 8 }}>
                        <Pressable style={styles.smallBtn} onPress={() => openEditInjury(idx)}>
                          <Text style={styles.smallBtnText}>Modifica</Text>
                        </Pressable>
                        <Pressable
                          style={[styles.smallBtn, { backgroundColor: '#b91c1c' }]}
                          onPress={() => deleteInjury(idx)}
                        >
                          <Text style={[styles.smallBtnText, { color: 'white' }]}>Elimina</Text>
                        </Pressable>
                      </View>
                    </View>
                  ))}
              </View>
            )}
          </View>
        )}

        {tab === 'ALLEGATI' && (
          <View>
            <Text style={styles.sectionTitle}>Allegati</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8 }}>
              <Pressable style={[styles.actionBtn, { backgroundColor: '#1b4f7f' }]} onPress={addAttachment}>
                <Text style={styles.actionText}>+ Aggiungi allegato</Text>
              </Pressable>
            </View>
            <FlatList
              data={attachments}
              keyExtractor={(item) => item.uri}
              ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
              renderItem={({ item }) => (
                <View style={styles.attachRow}>
                  <Pressable style={{ flex: 1 }} onPress={() => openAttachment(item.uri)}>
                    <Text numberOfLines={1} style={{ fontWeight: '600' }}>{item.name}</Text>
                    <Text numberOfLines={1} style={{ color: '#555', marginTop: 2 }}>{item.uri}</Text>
                  </Pressable>
                  <Pressable onPress={() => removeAttachment(item.uri)} style={styles.trashBtn}>
                    <Text style={{ fontSize: 18 }}>🗑️</Text>
                  </Pressable>
                </View>
              )}
              ListEmptyComponent={<Text style={{ color: '#666' }}>Nessun allegato</Text>}
            />
          </View>
        )}
      </View>

      {/* MODALE: aggiungi/modifica infortunio */}
      <Modal
        visible={injuryModal}
        transparent
        animationType="slide"
        onRequestClose={() => setInjuryModal(false)}
      >
        <View style={styles.overlay}>
          <View style={styles.sheet}>
            <Text style={styles.modalTitle}>{editIdx !== null ? 'Modifica infortunio' : 'Nuovo infortunio'}</Text>
            <ScrollView contentContainerStyle={{ paddingBottom: 12 }}>
              <Text style={styles.label}>Tipologia</Text>
              <TextInput
                value={injType}
                onChangeText={setInjType}
                placeholder="Es. Distrazione flessore"
                style={[styles.input, !injType && styles.inputWarn]}
              />

              <Text style={styles.label}>Dal</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Pressable style={styles.dateBtn} onPress={() => setPickWhichDate('FROM')}>
                  <Text style={styles.dateBtnText}>📅 Scegli data</Text>
                </Pressable>
                <Text style={{ fontWeight: '700', color: injFrom ? '#111' : '#b91c1c' }}>
                  {injFrom || '— (obbligatoria)'}
                </Text>
              </View>

              <Text style={styles.label}>Al (opzionale)</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Pressable style={styles.dateBtn} onPress={() => setPickWhichDate('TO')}>
                  <Text style={styles.dateBtnText}>📅 Scegli data</Text>
                </Pressable>
                <Text style={{ fontWeight: '700' }}>{injTo || '—'}</Text>
              </View>

              <Text style={styles.label}>Note (opzionale)</Text>
              <TextInput
                value={injNote}
                onChangeText={setInjNote}
                placeholder="Dettagli aggiuntivi…"
                style={styles.input}
                multiline
              />

              <Pressable
                style={[styles.createBtn, !(injFrom && injType) && { opacity: 0.6 }]}
                disabled={!(injFrom && injType)}
                onPress={persistInjury}
              >
                <Text style={styles.createText}>{editIdx !== null ? 'Salva modifiche' : 'Aggiungi infortunio'}</Text>
              </Pressable>
              <Pressable style={styles.cancelBtn} onPress={() => setInjuryModal(false)}>
                <Text style={styles.cancelText}>Chiudi</Text>
              </Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Sotto-modale: calendario per FROM/TO */}
      <Modal
        visible={pickWhichDate !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setPickWhichDate(null)}
      >
        <View style={styles.confirmOverlay}>
          <View style={[styles.confirmCard, { paddingBottom: 10 }]}>
            <Text style={styles.confirmTitle}>
              Seleziona data {pickWhichDate === 'FROM' ? 'inizio' : 'fine'}
            </Text>
            <Calendar
              onDayPress={(day: CalendarDay) => {
                if (pickWhichDate === 'FROM') setInjFrom(day.dateString);
                if (pickWhichDate === 'TO') setInjTo(day.dateString);
              }}
              markedDates={
                pickWhichDate === 'FROM' && injFrom
                  ? { [injFrom]: { selected: true, selectedColor: '#1b7f3b' } }
                  : pickWhichDate === 'TO' && injTo
                  ? { [injTo]: { selected: true, selectedColor: '#1b7f3b' } }
                  : {}
              }
              theme={{ todayTextColor: '#1b7f3b', selectedDayBackgroundColor: '#1b7f3b' }}
            />
            <View style={styles.confirmRow}>
              <Pressable style={[styles.confirmBtn, styles.confirmCancel]} onPress={() => setPickWhichDate(null)}>
                <Text style={styles.confirmCancelText}>Chiudi</Text>
              </Pressable>
              <Pressable style={[styles.confirmBtn, styles.confirmDelete]} onPress={() => setPickWhichDate(null)}>
                <Text style={styles.confirmDeleteText}>OK</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  container: { flex: 1, backgroundColor: '#fff' },

  stickyHeader: {
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  headerActions: { marginTop: 10, flexDirection: 'row', gap: 8 },
  photo: { width: 90, height: 90, borderRadius: 45 },
  placeholder: {
    width: 90, height: 90, borderRadius: 45, backgroundColor: '#ddd',
    alignItems: 'center', justifyContent: 'center',
  },
  name: { fontSize: 18, fontWeight: '800', marginBottom: 2 },

  tabRow: { flexDirection: 'row', gap: 8, marginTop: 12, flexWrap: 'wrap' },
  tabBtn: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 999, backgroundColor: '#eef2f7' },
  tabBtnActive: { backgroundColor: '#1b7f3b' },
  tabText: { fontWeight: '700', color: '#111' },
  tabTextActive: { color: 'white' },

  sectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 8 },

  actionBtn: { backgroundColor: '#1b4f7f', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8 },
  actionText: { color: 'white', fontWeight: '700' },

  // Allegati
  attachRow: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 12,
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  trashBtn: {
    paddingVertical: 6, paddingHorizontal: 8, backgroundColor: '#fff', borderRadius: 8, borderWidth: 1, borderColor: '#ddd',
  },

  // Infortuni
  injuryRow: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    borderRadius: 12,
    backgroundColor: '#f8fafc',
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  smallBtn: { paddingVertical: 6, paddingHorizontal: 10, backgroundColor: '#e5e7eb', borderRadius: 8 },
  smallBtnText: { fontWeight: '700', color: '#111' },

  // Modali
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  sheet: { backgroundColor: 'white', borderRadius: 10, width: '92%', maxHeight: '92%', padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10 },
  label: { fontWeight: '700', marginTop: 10 },
  input: {
    borderWidth: 1, borderColor: '#ccc', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 8, marginTop: 6, backgroundColor: 'white',
  },
  inputWarn: { borderColor: '#f59e0b' },

  // Bottoni modale
  createBtn: { backgroundColor: '#1b7f3b', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 12 },
  createText: { color: 'white', fontWeight: '800' },
  cancelBtn: { marginTop: 8, padding: 10, borderRadius: 8, alignItems: 'center', backgroundColor: '#ddd' },
  cancelText: { fontWeight: '700' },
  dateBtn: {
      backgroundColor: '#1b4f7f',
      paddingVertical: 6,
      paddingHorizontal: 10,
      borderRadius: 6,
    },
  dateBtnText: {
    color: 'white',
    fontWeight: '700',
  },
  // Date picker sub-modal
  confirmOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center' },
  confirmCard: { backgroundColor: 'white', borderRadius: 10, width: '86%', padding: 16 },
  confirmTitle: { fontSize: 16, fontWeight: '800', marginBottom: 12 },
  confirmRow: { flexDirection: 'row', gap: 8, marginTop: 10 },
  confirmBtn: { flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  confirmCancel: { backgroundColor: '#e5e7eb' },
  confirmCancelText: { fontWeight: '700', color: '#111' },
  confirmDelete: { backgroundColor: '#1b7f3b' },
  confirmDeleteText: { fontWeight: '800', color: 'white' },
});

const stylesCard = StyleSheet.create({
  card: {
    backgroundColor: '#eef6ee',
    borderRadius: 10,
    padding: 12,
    marginTop: 8,
  },
  title: { fontWeight: '800', fontSize: 16, color: '#1b7f3b', marginBottom: 6 },
  value: { fontSize: 16, fontWeight: '700' },
  subtitle: { marginTop: 6, fontWeight: '700' },
  trendRow: { flexDirection: 'row', gap: 6, marginTop: 6 },
  dot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#ccc' },
  dotOk: { backgroundColor: '#1b7f3b' },
  dotKo: { backgroundColor: '#b22222' },
  
  monthRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginTop: 6,
  },
});
