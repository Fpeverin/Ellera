import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { FlatList, Image, Modal, Pressable, StyleSheet, Text, View } from 'react-native';

export type TacticElementType = 'HOME' | 'AWAY' | 'BALL';
export type TacticItem = {
  id: string;
  name: string;
  preview?: string; // base64 (senza prefisso)
  elements: { id: string; type: TacticElementType; x: number; y: number; number?: number }[];
};

const TACTICS_KEY = 'tactics/custom';

export default function TatticheIndex() {
  const router = useRouter();
  const [tactics, setTactics] = useState<TacticItem[]>([]);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const raw = await AsyncStorage.getItem(TACTICS_KEY);
    const list: TacticItem[] = raw ? JSON.parse(raw) : [];
    setTactics(list);
  };

  useFocusEffect(
    useCallback(() => {
      load();
    }, [])
  );

  const createNew = () => {
    router.push('/squadra/tattiche/editor');
  };

  const openItem = (id: string) => {
    router.push({ pathname: '/squadra/tattiche/editor', params: { id } });
  };

  // === pattern uguale alle partite ===
  const actuallyDeleteOne = async () => {
    if (!confirmDeleteId) return;
    setBusy(true);
    const raw = await AsyncStorage.getItem(TACTICS_KEY);
    const all: TacticItem[] = raw ? JSON.parse(raw) : [];
    const updated = all.filter(t => t.id !== confirmDeleteId);
    await AsyncStorage.setItem(TACTICS_KEY, JSON.stringify(updated));
    setBusy(false);
    setConfirmDeleteId(null);
    load();
  };

  const renderItem = ({ item }: { item: TacticItem }) => (
    <View style={styles.card}>
      <Pressable style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 }} onPress={() => openItem(item.id)}>
        {item.preview ? (
          <Image source={{ uri: `data:image/png;base64,${item.preview}` }} style={styles.preview} />
        ) : (
          <View style={[styles.preview, styles.previewPlaceholder]}>
            <Text style={{ color: '#6b7280', fontSize: 12 }}>Nessuna preview</Text>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.meta}>{item.elements.length} elementi</Text>
        </View>
      </Pressable>
      <Pressable style={styles.deleteBtn} onPress={() => setConfirmDeleteId(item.id)}>
        <Text style={styles.deleteText}>🗑️</Text>
      </Pressable>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Text style={styles.title}>Tattiche</Text>
        <Pressable style={styles.createBtn} onPress={createNew}>
          <Text style={styles.createBtnText}>＋ Crea nuova</Text>
        </Pressable>
      </View>

      <FlatList
        data={tactics}
        keyExtractor={(it) => it.id}
        ListEmptyComponent={<Text style={{ color: '#6b7280' }}>Nessuna tattica salvata</Text>}
        renderItem={renderItem}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      {/* Modale conferma cancellazione singola */}
      <Modal visible={!!confirmDeleteId} transparent animationType="fade" onRequestClose={() => setConfirmDeleteId(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Eliminare questa tattica?</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <Pressable style={[styles.btn, { backgroundColor: '#9ca3af', flex: 1 }]} onPress={() => setConfirmDeleteId(null)}>
                <Text style={styles.btnText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.btn, { backgroundColor: '#b91c1c', flex: 1, opacity: busy ? 0.6 : 1 }]}
                disabled={busy}
                onPress={actuallyDeleteOne}
              >
                <Text style={styles.btnText}>Elimina</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12, backgroundColor: '#fff' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  title: { fontSize: 22, fontWeight: '800' },
  createBtn: { backgroundColor: '#1b7f3b', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8 },
  createBtnText: { color: 'white', fontWeight: '800' },

  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f4f6f8', borderRadius: 10, padding: 10, gap: 10 },
  preview: { width: 100, height: 60, borderRadius: 6, backgroundColor: '#e5e7eb' },
  previewPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  name: { fontWeight: '800', fontSize: 16 },
  meta: { color: '#6b7280', marginTop: 2, fontSize: 12 },
  deleteBtn: { paddingHorizontal: 8, paddingVertical: 6 },
  deleteText: { fontSize: 16 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '90%', maxWidth: 420, backgroundColor: '#fff', borderRadius: 12, padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  btn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  btnText: { color: 'white', fontWeight: '800', textAlign: 'center' },
});
