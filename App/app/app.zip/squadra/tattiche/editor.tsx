// app/squadra/tattiche/editor.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams, useRouter, type Href } from 'expo-router';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Dimensions, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import ViewShot, { captureRef } from 'react-native-view-shot';

type TacticElementType = 'HOME' | 'AWAY' | 'BALL';
type TacticElement = { id: string; type: TacticElementType; x: number; y: number; number?: number };
type TacticItem = { id: string; name: string; preview?: string; elements: TacticElement[] };

const TACTICS_KEY = 'tactics/custom';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const FIELD_W = Math.round(SCREEN_W * 0.7);
const FIELD_H = Math.max(Math.round(SCREEN_H * 0.8), 520);

const SHIRT_W = 54;
const SHIRT_H = 36;
const BALL_SIZE = 22;

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

/* ---- Render elementi ---- */
function HomeShirt({ number }: { number?: number }) {
  return (
    <View style={styles.fieldShirtBody}>
      {[0,1,2,3,4].map(i => (
        <View key={i} style={{ flex:1, backgroundColor: i%2===0 ? '#ffffff' : '#3b82f6' }} />
      ))}
      <View style={[styles.fieldSleeve, { left: -10 }]} />
      <View style={[styles.fieldSleeve, { right: -10 }]} />
      <Text style={styles.fieldShirtNum}>{number ?? ''}</Text>
    </View>
  );
}
function AwayShirt({ number }: { number?: number }) {
  return (
    <View style={[styles.fieldShirtBody, { borderColor: 'rgba(0,0,0,0.2)' }]}>
      {[0,1,2,3,4].map(i => (
        <View key={i} style={{ flex:1, backgroundColor: i%2===0 ? '#ef4444' : '#b91c1c' }} />
      ))}
      <View style={[styles.fieldSleeve, { left: -10, backgroundColor: '#ef4444' }]} />
      <View style={[styles.fieldSleeve, { right: -10, backgroundColor: '#ef4444' }]} />
      <Text style={[styles.fieldShirtNum, { color: '#fff' }]}>{number ?? ''}</Text>
    </View>
  );
}
function Ball() {
  return (
    <View style={styles.ball}>
      <Text style={{ fontWeight: '900' }}>⚽</Text>
    </View>
  );
}

/* ---- Draggable generico ---- */
function Draggable({
  idx, xPct, yPct, onMove, children,
}: { idx: number; xPct: number; yPct: number; onMove: (i:number, nx:number, ny:number)=>void; children: React.ReactNode }) {
  const x = useSharedValue((xPct / 100) * FIELD_W - SHIRT_W / 2);
  const y = useSharedValue((yPct / 100) * FIELD_H - SHIRT_H / 2);

  const pan = Gesture.Pan()
    .onChange((e) => { x.value += e.changeX; y.value += e.changeY; })
    .onEnd(() => {
      const nx = Math.max(0, Math.min(100, ((x.value + SHIRT_W / 2) / FIELD_W) * 100));
      const ny = Math.max(0, Math.min(100, ((y.value + SHIRT_H / 2) / FIELD_H) * 100));
      onMove(idx, nx, ny);
    });

  const style = useAnimatedStyle(() => ({
    position: 'absolute',
    left: withSpring(x.value, { damping: 18, stiffness: 220 }),
    top: withSpring(y.value, { damping: 18, stiffness: 220 }),
    width: SHIRT_W,
    height: SHIRT_H,
    alignItems: 'center',
    justifyContent: 'center',
  }));

  return (
    <GestureDetector gesture={pan}>
      <Animated.View style={style}>{children}</Animated.View>
    </GestureDetector>
  );
}

export default function TacticsEditor() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const isEditing = !!id;

  const [title, setTitle] = useState('');
  const [elements, setElements] = useState<TacticElement[]>([]);
  const [showNameModal, setShowNameModal] = useState(false);

  const shotRef = useRef<ViewShot>(null);

  // carica se editing
  useEffect(() => {
    (async () => {
      if (!isEditing) return;
      const raw = await AsyncStorage.getItem(TACTICS_KEY);
      const list: TacticItem[] = raw ? JSON.parse(raw) : [];
      const found = list.find(t => t.id === id);
      if (found) {
        setTitle(found.name);
        setElements(found.elements);
      }
    })();
  }, [id, isEditing]);

  // pannello destra: bottoni numerati
  const jerseyButtons = useMemo(() => Array.from({ length: 11 }, (_, i) => i + 1), []);

  const addHome = () => {
    const numbers = elements.filter(e => e.type === 'HOME').map(e => e.number ?? 0);
    let next = 1; while (numbers.includes(next) && next <= 99) next++;
    setElements(prev => [...prev, { id: uid(), type: 'HOME', x: 50, y: 80, number: next }]);
  };
  const addAway = () => {
    const numbers = elements.filter(e => e.type === 'AWAY').map(e => e.number ?? 0);
    let next = 1; while (numbers.includes(next) && next <= 99) next++;
    setElements(prev => [...prev, { id: uid(), type: 'AWAY', x: 50, y: 20, number: next }]);
  };
  const addBall = () => {
    if (elements.some(e => e.type === 'BALL')) {
      Alert.alert('Pallone già presente', 'C’è già un pallone: spostalo dove preferisci.');
      return;
    }
    setElements(prev => [...prev, { id: uid(), type: 'BALL', x: 50, y: 50 }]);
  };

  const handleMove = (idx: number, nx: number, ny: number) => {
    setElements(prev => {
      const next = [...prev];
      next[idx] = { ...next[idx], x: nx, y: ny };
      return next;
    });
  };

  const removeAt = (idx: number) => {
    setElements(prev => prev.filter((_, i) => i !== idx));
  };

  /* -------------------- salva con conferma + preview -------------------- */
  const doSave = async () => {
    // genera preview
    let previewBase64: string | undefined;
    try {
      if (shotRef.current) {
        previewBase64 = await captureRef(shotRef, {
          result: 'base64',
          format: 'png',
          quality: 0.6,
          width: 700,
        });
      }
    } catch {
      // ignora eventuali errori preview
    }

    const raw = await AsyncStorage.getItem(TACTICS_KEY);
    const list: TacticItem[] = raw ? JSON.parse(raw) : [];

    if (isEditing) {
      const idx = list.findIndex(t => t.id === id);
      if (idx >= 0) {
        list[idx] = {
          ...list[idx],
          name: title.trim(),
          elements,
          preview: previewBase64 ?? list[idx].preview,
        };
      }
    } else {
      list.push({
        id: uid(),
        name: title.trim(),
        elements,
        preview: previewBase64,
      });
    }

    await AsyncStorage.setItem(TACTICS_KEY, JSON.stringify(list));
    router.replace('/squadra/tattiche' as Href);
  };

  const requestSave = () => {
    if (!title.trim()) {
      setShowNameModal(true);
      return;
    }
    Alert.alert(
      isEditing ? 'Aggiornare questa tattica?' : 'Salvare nuova tattica?',
      '',
      [
        { text: 'Annulla', style: 'cancel' },
        { text: 'Conferma', style: 'destructive', onPress: doSave },
      ],
      { cancelable: true }
    );
  };

  /* --------------------------- reset con conferma -------------------------- */
  const confirmReset = () => {
    Alert.alert(
      'Ripulire il campo?',
      'Questa azione rimuove tutti i giocatori e il pallone.',
      [
        { text: 'Annulla', style: 'cancel' },
        {
          text: 'Conferma',
          style: 'destructive',
          onPress: () => setElements([]),
        },
      ]
    );
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        {/* SINISTRA: campo con snapshot */}
        <View style={styles.leftCol}>
          <Text style={styles.title}>{isEditing ? 'Modifica Tattica' : 'Nuova Tattica'}</Text>

          <ViewShot ref={shotRef} style={styles.fieldShot}>
            <View style={styles.field}>
              {/* linee campo */}
              <View style={styles.midLine} />
              <View style={styles.centerCircle} />
              {/* aree & porte */}
              <View style={[styles.penaltyBox, styles.topPenaltyBox]} />
              <View style={[styles.sixYardBox, styles.topSixYard]} />
              <View style={[styles.goal, styles.topGoal]} />
              <View style={[styles.penaltyBox, styles.bottomPenaltyBox]} />
              <View style={[styles.sixYardBox, styles.bottomSixYard]} />
              <View style={[styles.goal, styles.bottomGoal]} />

              {elements.map((el, i) => {
                const child =
                  el.type === 'HOME' ? <HomeShirt number={el.number} /> :
                  el.type === 'AWAY' ? <AwayShirt number={el.number} /> :
                  <Ball />;

                const wrapW = el.type === 'BALL' ? BALL_SIZE : SHIRT_W;
                const wrapH = el.type === 'BALL' ? BALL_SIZE : SHIRT_H;

                return (
                  <Draggable key={el.id} idx={i} xPct={el.x} yPct={el.y} onMove={handleMove}>
                    <Pressable
                      style={{ width: wrapW, height: wrapH, alignItems: 'center', justifyContent: 'center' }}
                      onLongPress={() => removeAt(i)}
                    >
                      {child}
                    </Pressable>
                  </Draggable>
                );
              })}
            </View>
          </ViewShot>

          <View style={styles.bottomBar}>
            <Pressable style={[styles.btn, { backgroundColor: '#d46f00' }]} onPress={confirmReset}>
              <Text style={styles.btnText}>Reset</Text>
            </Pressable>
            <Pressable style={[styles.btn, { backgroundColor: '#1b7f3b' }]} onPress={requestSave}>
              <Text style={styles.btnText}>Salva</Text>
            </Pressable>
          </View>
        </View>

        {/* DESTRA: pannello strumenti */}
        <View style={styles.rightCol}>
          <Text style={styles.panelTitle}>Nome tattica</Text>
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder="Es. Uscita palla 3+2"
            style={styles.input}
          />

          <Text style={styles.panelTitle}>Aggiungi giocatori (nostri)</Text>
          <View style={styles.jerseysWrap}>
            {jerseyButtons.map(n => (
              <Pressable key={`H${n}`} style={styles.shirtBtn} onPress={addHome}>
                <View style={styles.shirtBodyMini}>
                  {[0,1,2,3,4].map(i => (
                    <View key={i} style={{ flex:1, backgroundColor: i%2===0 ? '#fff' : '#3b82f6' }} />
                  ))}
                </View>
                <Text style={styles.shirtBtnNum}>{n}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.panelTitle}>Aggiungi avversari</Text>
          <View style={styles.jerseysWrap}>
            {jerseyButtons.map(n => (
              <Pressable key={`A${n}`} style={styles.shirtBtn} onPress={addAway}>
                <View style={styles.shirtBodyMini}>
                  {[0,1,2,3,4].map(i => (
                    <View key={i} style={{ flex:1, backgroundColor: i%2===0 ? '#ef4444' : '#b91c1c' }} />
                  ))}
                </View>
                <Text style={[styles.shirtBtnNum, { color: '#fff' }]}>{n}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.panelTitle}>Pallone</Text>
          <Pressable style={styles.ballBtn} onPress={addBall}>
            <Text style={{ fontSize: 18 }}>⚽ Aggiungi pallone</Text>
          </Pressable>
        </View>
      </View>

      {/* Modal nome (se manca) */}
      <Modal visible={showNameModal} transparent animationType="fade" onRequestClose={() => setShowNameModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Nome tattica</Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="Es. Pressing alto 4-3-3"
              style={styles.input}
            />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Pressable style={[styles.btn, { backgroundColor: '#9ca3af', flex: 1 }]} onPress={() => setShowNameModal(false)}>
                <Text style={styles.btnText}>Annulla</Text>
              </Pressable>
              <Pressable
                style={[styles.btn, { backgroundColor: '#1b7f3b', flex: 1 }]}
                onPress={() => {
                  if (!title.trim()) { Alert.alert('Inserisci un nome valido'); return; }
                  setShowNameModal(false);
                  setTimeout(requestSave, 0);
                }}
              >
                <Text style={styles.btnText}>Continua</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
}

/* ------------------------------- STILI ------------------------------- */

const LINE = 'rgba(255,255,255,0.7)';

const styles = StyleSheet.create({
  container: { flex: 1, flexDirection: 'row', backgroundColor: '#f5f7fa' },
  leftCol: { flex: 7, padding: 12 },
  rightCol: { flex: 3, padding: 12, borderLeftWidth: 1, borderColor: '#e5e7eb', backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: '800', marginBottom: 8 },

  fieldShot: { width: '100%', height: FIELD_H },
  field: {
    width: '100%', height: '100%', backgroundColor: '#1b7f3b',
    borderRadius: 12, borderWidth: 3, borderColor: '#0d5f2b', overflow: 'hidden',
  },
  midLine: { position: 'absolute', left: 0, right: 0, top: '50%', height: 2, backgroundColor: LINE },
  centerCircle: {
    position: 'absolute', top: '50%', left: '50%', width: 120, height: 120,
    marginLeft: -60, marginTop: -60, borderWidth: 2, borderColor: LINE, borderRadius: 60,
  },
  penaltyBox: { position: 'absolute', width: '60%', height: '18%', left: '20%', borderColor: LINE, borderWidth: 2 },
  sixYardBox: { position: 'absolute', width: '36%', height: '6%', left: '32%', borderColor: LINE, borderWidth: 2 },
  goal: { position: 'absolute', width: '16%', height: 4, left: '42%', backgroundColor: LINE },
  topPenaltyBox: { top: '4%' },
  topSixYard: { top: '4%' },
  topGoal: { top: '1.2%' },
  bottomPenaltyBox: { bottom: '4%' },
  bottomSixYard: { bottom: '4%' },
  bottomGoal: { bottom: '1.2%' },

  bottomBar: { flexDirection: 'row', gap: 10, marginTop: 10 },
  btn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  btnText: { color: 'white', fontWeight: '800', textAlign: 'center' },

  panelTitle: { fontSize: 16, fontWeight: '800', marginTop: 6, marginBottom: 6 },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 10, backgroundColor: '#fff' },

  jerseysWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  shirtBtn: {
    width: '30%', aspectRatio: 1.4, backgroundColor: '#eef2ff',
    borderWidth: 1, borderColor: '#c7d2fe', borderRadius: 10, alignItems: 'center', justifyContent: 'center',
  },
  shirtBodyMini: {
    width: 44, height: 28, borderRadius: 8, overflow: 'hidden', flexDirection: 'row', marginBottom: 2,
  },
  shirtBtnNum: { fontWeight: '900', color: '#0f172a' },

  fieldShirtBody: {
    width: SHIRT_W, height: SHIRT_H, flexDirection: 'row',
    borderTopLeftRadius: 12, borderTopRightRadius: 12, borderBottomLeftRadius: 10, borderBottomRightRadius: 10,
    overflow: 'hidden', borderWidth: 2, borderColor: 'rgba(0,0,0,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  fieldSleeve: { position: 'absolute', top: 6, width: 18, height: 18, borderRadius: 5, backgroundColor: '#3b82f6' },
  fieldShirtNum: { position: 'absolute', color: '#111', fontWeight: '900', fontSize: 12 },

  ball: {
    width: BALL_SIZE, height: BALL_SIZE, borderRadius: BALL_SIZE/2,
    backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: '#111',
  },
  ballBtn: {
    paddingVertical: 10, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db',
    alignItems: 'center', marginTop: 4, backgroundColor: '#f9fafb',
  },

  // modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '90%', maxWidth: 520, backgroundColor: '#fff', borderRadius: 12, padding: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10 },
});
