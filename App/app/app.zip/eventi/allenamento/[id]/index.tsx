// app/eventi/allenamento/[id].tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { CalendarEvent, STORAGE_KEY } from '../../../data/events';
import { players } from '../../../data/players';

export default function AllenamentoDettaglio() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [event, setEvent] = useState<CalendarEvent | null>(null);
  const [presenze, setPresenze] = useState<Record<string, boolean>>({});
  const [tema, setTema] = useState('');

  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const list: CalendarEvent[] = JSON.parse(raw);
      const found = list.find(ev => ev.id === id);
      if (!found) return;

      setEvent(found);
      setPresenze(found.presenze ?? {});
      setTema(found.temaAllenamento ?? '');
    })();
  }, [id]);

  const sortedPlayers = useMemo(
    () => [...players].sort((a, b) => a.name.localeCompare(b.name, 'it', { sensitivity: 'base' })),
    []
  );

  const save = async (newPresenze: Record<string, boolean>, newTema: string) => {
    if (!event) return;
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const list: CalendarEvent[] = JSON.parse(raw);
    const updatedList = list.map(ev =>
      ev.id === event.id ? { ...ev, presenze: newPresenze, temaAllenamento: newTema } : ev
    );
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedList));
    setEvent(prev => (prev ? { ...prev, presenze: newPresenze, temaAllenamento: newTema } : prev));
  };

  const togglePresenza = (playerId: string) => {
    setPresenze(prev => {
      const updated = { ...prev, [playerId]: !prev[playerId] };
      // persisto subito
      save(updated, tema);
      return updated;
    });
  };

  if (!event) {
    return (
      <View style={styles.container}>
        <Text>Evento non trovato</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Allenamento</Text>
      <Text style={styles.meta}>{event.date} · {event.time} · {event.location}</Text>

      <Text style={styles.subtitle}>Tema allenamento</Text>
      <TextInput
        style={styles.input}
        value={tema}
        onChangeText={(t) => {
          setTema(t);
          save(presenze, t);
        }}
        placeholder="Inserisci tema..."
      />

      <Text style={styles.subtitle}>Presenze</Text>
      <FlatList
        data={sortedPlayers}
        keyExtractor={(item) => item.id}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        renderItem={({ item }) => (
          <Pressable style={styles.row} onPress={() => togglePresenza(item.id)}>
            <Text style={{ flex: 1 }}>{item.name}</Text>
            <Text style={styles.badge}>{presenze[item.id] ? '✅ Presente' : '⬜ Assente'}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 4 },
  meta: { color: '#444', marginBottom: 12 },
  subtitle: { fontSize: 16, fontWeight: '700', marginTop: 16, marginBottom: 6 },
  input: {
    borderWidth: 1, borderColor: '#ccc', paddingHorizontal: 10, paddingVertical: 8, borderRadius: 6,
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#f3f4f6', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8,
  },
  badge: { fontWeight: '700' },
});
