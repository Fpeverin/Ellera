// app/eventi/partita/[id]/live.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import {
  FlatList,
  Image,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { CalendarEvent, STORAGE_KEY } from '../../../data/events';
import { players } from '../../../data/players';
import { Tactic, tactics } from '../../../data/tactics';
import { FieldSlot, MODULES } from '../../../utils/modules-layout';

type MatchPhase = 'PRE_MATCH' | 'FIRST_HALF' | 'HALF_TIME' | 'SECOND_HALF' | 'FULL_TIME';
type FormationItem = { slot: FieldSlot; playerId?: string };

function normalizeFormationSlots(input: unknown, fallbackModule: string): FormationItem[] {
  if (!Array.isArray(input)) {
    return (MODULES[fallbackModule] ?? MODULES['4-4-2']).map(slot => ({ slot }));
  }
  const first = input[0] as any;
  if (first && first.slot) {
    return (input as any[]).map(it => ({ slot: it.slot, playerId: it.playerId }));
  }
  return (input as any[]).map(it => ({
    slot: { id: it.id, x: it.x, y: it.y },
    playerId: it.playerId,
  }));
}

export default function LivePartita() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const [event, setEvent] = useState<CalendarEvent | null>(null);
  const [time, setTime] = useState(0);
  const [phase, setPhase] = useState<MatchPhase>('PRE_MATCH');
  const [isRunning, setIsRunning] = useState(false);

  const [selectedModule, setSelectedModule] = useState<string>('4-4-2');
  const [formationSlots, setFormationSlots] = useState<FormationItem[]>([]);
  const [benchIds, setBenchIds] = useState<string[]>([]);
  const [assignedTactics, setAssignedTactics] = useState<string[]>([]);
  const [tacticModalVisible, setTacticModalVisible] = useState(false);

  const [slotToFill, setSlotToFill] = useState<number | null>(null);
  const [playerModalVisible, setPlayerModalVisible] = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load evento
  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const list: CalendarEvent[] = JSON.parse(raw);
      const found = list.find(ev => ev.id === id);
      if (!found) return;

      const moduleFromEvent =
        found.module && MODULES[found.module] ? found.module : '4-4-2';

      setEvent(found);
      setSelectedModule(moduleFromEvent);
      setFormationSlots(normalizeFormationSlots(found.formationSlots, moduleFromEvent));
      setBenchIds(found.benchIds ?? []);
      setAssignedTactics(found.tacticsIds ?? []);
    })();
  }, [id]);

  // Cronometro
  useEffect(() => {
    if (isRunning && (phase === 'FIRST_HALF' || phase === 'SECOND_HALF')) {
      timerRef.current = setInterval(() => setTime(prev => prev + 1), 1000);
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isRunning, phase]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // ---- CRONOMETRO ----
  const handleStart = () => {
    if (phase === 'PRE_MATCH') setPhase('FIRST_HALF');
    setIsRunning(true);
  };

  const handlePause = () => setIsRunning(false);

  const handleReset = () => {
    setIsRunning(false);
    setTime(0);
    setPhase('PRE_MATCH');
  };

  const handlePhaseChange = () => {
    if (phase === 'FIRST_HALF') {
      setPhase('HALF_TIME');
      setTime(45 * 60); // forzo 45:00
      setIsRunning(false);
    } else if (phase === 'HALF_TIME') {
      setPhase('SECOND_HALF');
      setIsRunning(true);
    } else if (phase === 'SECOND_HALF') {
      setPhase('FULL_TIME');
      setTime(90 * 60); // forzo 90:00
      setIsRunning(false);
    }
  };

  // ---- FORMAZIONE ----
  const isEditable = phase === 'PRE_MATCH'; // in live si permetteranno solo sostituzioni in futuro

  const saveEvent = async (
    formation: FormationItem[],
    bench: string[],
    tacticsIds: string[],
    moduleName?: string
  ) => {
    if (!event) return;
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const list: CalendarEvent[] = JSON.parse(raw);
    const updatedList = list.map(ev =>
      ev.id === event.id
        ? {
            ...ev,
            formationSlots: formation,
            benchIds: bench,
            tacticsIds,
            module: moduleName ?? ev.module ?? selectedModule,
          }
        : ev
    );
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedList));
    setEvent(prev =>
      prev
        ? {
            ...prev,
            formationSlots: formation,
            benchIds: bench,
            tacticsIds,
            module: moduleName ?? prev.module ?? selectedModule,
          }
        : prev
    );
  };

  const handleSelectPlayerForSlot = (playerId: string) => {
    if (!isEditable || slotToFill === null) return;
    const updated = [...formationSlots];
    updated[slotToFill].playerId = playerId;
    setFormationSlots(updated);
    setSlotToFill(null);
    setPlayerModalVisible(false);
    setBenchIds(prev => prev.filter(id2 => id2 !== playerId));
    saveEvent(updated, benchIds.filter(id2 => id2 !== playerId), assignedTactics);
  };

  const handleAddToBench = (playerId: string) => {
    if (!isEditable) return;
    if (benchIds.length >= 9) return;
    const updatedBench = [...benchIds, playerId];
    setBenchIds(updatedBench);
    saveEvent(formationSlots, updatedBench, assignedTactics);
  };

  const handleChangeModule = (moduleName: string) => {
    if (!isEditable) return;
    const fresh = (MODULES[moduleName] ?? MODULES['4-4-2']).map(slot => ({ slot }));
    setSelectedModule(moduleName);
    setFormationSlots(fresh);
    saveEvent(fresh, benchIds, assignedTactics, moduleName);
  };

  const handleAddTactic = (tId: string) => {
    if (!isEditable) return;
    if (assignedTactics.includes(tId)) {
      setTacticModalVisible(false);
      return;
    }
    const updated = [...assignedTactics, tId];
    setAssignedTactics(updated);
    saveEvent(formationSlots, benchIds, updated);
    setTacticModalVisible(false);
  };

  if (!event) {
    return (
      <View style={styles.container}>
        <Text>Evento non trovato</Text>
      </View>
    );
  }

  const allPlayerIdsInUse = [
    ...formationSlots.map(fs => fs.playerId).filter(Boolean),
    ...benchIds,
  ] as string[];

  const availablePlayers = players.filter(p => !allPlayerIdsInUse.includes(p.id));

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        {/* Header & Cronometro */}
        <Text style={styles.title}>
          Live: {event.opponent ?? 'Partita'} - {formatTime(time)}
        </Text>
        <View style={styles.timerButtons}>
         {/* Start/Pause unificato */}
{phase !== 'FULL_TIME' && (
  <Pressable
    style={styles.button}
    onPress={() => {
      if (phase === 'FIRST_HALF' || phase === 'SECOND_HALF') {
        if (isRunning) {
          handlePause();   // se corre → pausa
        } else {
          handleStart();   // se in pausa → riparte
        }
      } else {
        handleStart();     // da PRE_MATCH o HALF_TIME → start
      }
    }}
  >
    <Text style={styles.buttonText}>
      {phase === 'FIRST_HALF' || phase === 'SECOND_HALF'
        ? isRunning
          ? 'Pause'   // se sta correndo
          : 'Start'   // se fermo
        : 'Start'}
    </Text>
  </Pressable>
)}


          {/* Reset */}
          <Pressable style={styles.button} onPress={handleReset}>
            <Text style={styles.buttonText}>Reset</Text>
          </Pressable>

          {/* Cambio Fase */}
          <Pressable style={styles.button} onPress={handlePhaseChange}>
            <Text style={styles.buttonText}>
              {phase === 'FIRST_HALF'
                ? 'Fine Primo Tempo'
                : phase === 'HALF_TIME'
                ? 'Inizia Secondo Tempo'
                : phase === 'SECOND_HALF'
                ? 'Fine Partita'
                : 'Terminata'}
            </Text>
          </Pressable>
        </View>

       {/* Modulo */}
      <Text style={styles.sectionTitle}>Modulo</Text>
      <View style={styles.pickerWrap}>
        <Picker
          selectedValue={selectedModule}
          enabled={isEditable} // disabilitato dopo lo start
          onValueChange={(value) => handleChangeModule(value as string)}
          style={styles.picker}
          mode="dropdown" // menu a tendina
        >
          {Object.keys(MODULES).map((m) => (
            <Picker.Item key={m} label={m} value={m} />
          ))}
        </Picker>
      </View>

        {/* Campo */}
        <View style={styles.field}>
          {formationSlots.map((fs, idx) => {
            const player = fs.playerId ? players.find(p => p.id === fs.playerId) : undefined;
            return (
              <TouchableOpacity
                key={fs.slot.id}
                style={[styles.slot, { left: `${fs.slot.x}%`, top: `${fs.slot.y}%` }]}
                onPress={() => {
                  if (isEditable) {
                    setSlotToFill(idx);
                    setPlayerModalVisible(true);
                  }
                }}
                activeOpacity={isEditable ? 0.6 : 1}
              >
                {player ? (
                  <Image
                    source={
                      (player as any).photo
                        ? { uri: (player as any).photo }
                        : require('../../../../assets/avatar.png')
                    }
                    style={styles.playerImage}
                  />
                ) : (
                  <View style={styles.emptySlot} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Panchina */}
        <Text style={styles.sectionTitle}>Panchina ({benchIds.length}/9)</Text>
        <FlatList
          horizontal
          data={benchIds.map(idp => players.find(p => p.id === idp)).filter(Boolean) as typeof players}
          keyExtractor={p => p.id}
          renderItem={({ item }) => (
            <View style={styles.benchPlayer}>
              <Image
                source={
                  (item as any).photo
                    ? { uri: (item as any).photo }
                    : require('../../../../assets/avatar.png')
                }
                style={styles.playerImage}
              />
              <Text>{item.name}</Text>
            </View>
          )}
        />
        {isEditable && (
          <FlatList
            horizontal
            data={availablePlayers}
            keyExtractor={p => p.id}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.benchPlayer} onPress={() => handleAddToBench(item.id)}>
                <Image
                  source={
                    (item as any).photo
                      ? { uri: (item as any).photo }
                      : require('../../../../assets/avatar.png')
                  }
                  style={styles.playerImage}
                />
                <Text>{item.name}</Text>
              </TouchableOpacity>
            )}
          />
        )}

        {/* Tattiche */}
        <Text style={styles.sectionTitle}>Tattiche</Text>
        {(assignedTactics ?? []).map(tid => {
          const t = tactics.find((tt: Tactic) => tt.id === tid);
          return (
            <View key={tid} style={styles.tacticItem}>
              <Text style={styles.tacticName}>{t?.name ?? 'Tattica'}</Text>
            </View>
          );
        })}
        {isEditable && (
          <Pressable style={styles.addTacticButton} onPress={() => setTacticModalVisible(true)}>
            <Text style={styles.addTacticButtonText}>Aggiungi Tattica</Text>
          </Pressable>
        )}

        {/* Modal selezione giocatore */}
        <Modal visible={playerModalVisible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Seleziona giocatore</Text>
              <FlatList
                data={availablePlayers}
                keyExtractor={p => p.id}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={styles.modalRow}
                    onPress={() => handleSelectPlayerForSlot(item.id)}
                  >
                    <Image
                      source={
                        (item as any).photo
                          ? { uri: (item as any).photo }
                          : require('../../../../assets/avatar.png')
                      }
                      style={[styles.playerImage, { marginRight: 8 }]}
                    />
                    <Text>{item.name}</Text>
                  </TouchableOpacity>
                )}
                ListEmptyComponent={<Text>Nessun giocatore disponibile</Text>}
              />
              <Pressable style={styles.closeModalButton} onPress={() => setPlayerModalVisible(false)}>
                <Text>Chiudi</Text>
              </Pressable>
            </View>
          </View>
        </Modal>

        {/* Modal Tattiche */}
        <Modal visible={tacticModalVisible} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Seleziona Tattica</Text>
              {tactics.map((t: Tactic) => (
                <TouchableOpacity
                  key={t.id}
                  style={styles.tacticSelectItem}
                  onPress={() => handleAddTactic(t.id)}
                >
                  <Text>{t.name}</Text>
                </TouchableOpacity>
              ))}
              <Pressable style={styles.closeModalButton} onPress={() => setTacticModalVisible(false)}>
                <Text>Chiudi</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 10 },
  timerButtons: { flexDirection: 'row', gap: 8, marginBottom: 10, flexWrap: 'wrap' },
  button: { backgroundColor: '#1b7f3b', paddingVertical: 8, paddingHorizontal: 10, borderRadius: 5 },
  buttonText: { color: 'white', fontWeight: '600' },

  sectionTitle: { fontSize: 16, fontWeight: '700', marginVertical: 8 },
  moduleButton: { padding: 8, borderWidth: 1, borderColor: '#ccc', marginRight: 5, borderRadius: 4 },
  moduleButtonActive: { backgroundColor: '#1b7f3b' },
  moduleButtonText: { color: 'black' },

  field: { height: 300, backgroundColor: '#3c8c3c', marginVertical: 10, position: 'relative' },
  slot: { position: 'absolute', transform: [{ translateX: -20 }, { translateY: -20 }] },
  emptySlot: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#ddd' },
  playerImage: { width: 40, height: 40, borderRadius: 20 },

  benchPlayer: { alignItems: 'center', marginRight: 8 },

  tacticItem: { padding: 5, backgroundColor: '#eee', marginBottom: 5 },
  tacticName: { fontWeight: '600' },
  addTacticButton: { backgroundColor: '#1b7f3b', padding: 8, borderRadius: 5, marginTop: 5 },
  addTacticButtonText: { color: 'white', textAlign: 'center' },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', padding: 20, borderRadius: 8, width: '85%', maxHeight: '80%' },
  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 10 },
  closeModalButton: { marginTop: 10, alignSelf: 'flex-end' },
  modalRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  tacticSelectItem: { paddingVertical: 10, borderBottomWidth: 1, borderColor: '#ccc' },
  pickerWrap: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 8,
  },
  picker: {
    height: 44,
  },
});
